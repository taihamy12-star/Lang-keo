import { CANDY_DEFS } from './candyConstants';

export function drawCheckerboard(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  grid: number,
  selected: { r: number; c: number } | null
) {
  const cellSize = width / grid;

  // Outer border & bevel
  ctx.save();

  for (let r = 0; r < grid; r++) {
    for (let c = 0; c < grid; c++) {
      const isEven = (r + c) % 2 === 0;
      const x = c * cellSize;
      const y = r * cellSize;

      // Checkerboard chocolate colors
      ctx.fillStyle = isEven ? '#4a2f26' : '#3d251d';
      ctx.fillRect(x, y, cellSize, cellSize);

      // Subtle inner square bevel
      ctx.strokeStyle = isEven ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.2)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x + 1, y + 1, cellSize - 2, cellSize - 2);

      // If selected
      if (selected && selected.r === r && selected.c === c) {
        ctx.fillStyle = 'rgba(255, 235, 59, 0.35)';
        ctx.fillRect(x, y, cellSize, cellSize);

        ctx.strokeStyle = '#ffee58';
        ctx.lineWidth = 3;
        ctx.strokeRect(x + 2, y + 2, cellSize - 4, cellSize - 4);
      }
    }
  }

  ctx.restore();
}

export function drawCandy(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  level: number,
  radius: number,
  scale = 1,
  rotation = 0
) {
  const def = CANDY_DEFS[level] || CANDY_DEFS[1];
  const r = radius * scale;

  ctx.save();
  ctx.translate(cx, cy);
  if (rotation !== 0) ctx.rotate(rotation);

  // Candy Drop Shadow
  ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
  ctx.shadowBlur = 6;
  ctx.shadowOffsetY = 4;

  switch (def.shape) {
    case 'bean': {
      // Level 1: Yellow Bean (curved kidney / half-moon jelly)
      ctx.beginPath();
      // Draw smooth bean
      ctx.moveTo(-r * 0.7, -r * 0.2);
      ctx.bezierCurveTo(-r * 0.9, -r * 0.8, r * 0.9, -r * 0.8, r * 0.7, -r * 0.2);
      ctx.bezierCurveTo(r * 0.9, r * 0.7, -r * 0.2, r * 0.9, -r * 0.7, -r * 0.2);
      ctx.closePath();

      const grad = ctx.createLinearGradient(-r, -r, r, r);
      grad.addColorStop(0, '#fff176');
      grad.addColorStop(0.4, '#fbc02d');
      grad.addColorStop(1, '#f57f17');
      ctx.fillStyle = grad;
      ctx.fill();

      // Inner stroke
      ctx.strokeStyle = '#f9a825';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Glossy highlight
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.2, -r * 0.35, r * 0.35, r * 0.12, -0.2, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
      ctx.fill();
      break;
    }

    case 'cone': {
      // Level 2: Purple Gumdrop (Hershey kiss / rounded cone)
      ctx.beginPath();
      ctx.moveTo(0, -r * 0.85);
      ctx.bezierCurveTo(r * 0.8, -r * 0.3, r * 0.85, r * 0.7, 0, r * 0.8);
      ctx.bezierCurveTo(-r * 0.85, r * 0.7, -r * 0.8, -r * 0.3, 0, -r * 0.85);
      ctx.closePath();

      const grad = ctx.createRadialGradient(-r * 0.2, -r * 0.2, r * 0.1, 0, 0, r * 0.9);
      grad.addColorStop(0, '#e1bee7');
      grad.addColorStop(0.5, '#ab47bc');
      grad.addColorStop(1, '#6a1b9a');
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.strokeStyle = '#8e24aa';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Top glossy highlight
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.2, -r * 0.3, r * 0.22, r * 0.14, -0.3, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.fill();
      break;
    }

    case 'oval': {
      // Level 3: Blue Oval Jelly
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.88, r * 0.62, -0.25, 0, Math.PI * 2);

      const grad = ctx.createLinearGradient(-r, -r * 0.6, r, r * 0.6);
      grad.addColorStop(0, '#81d4fa');
      grad.addColorStop(0.4, '#03a9f4');
      grad.addColorStop(1, '#0277bd');
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.strokeStyle = '#0288d1';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Glossy highlight
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.25, -r * 0.2, r * 0.35, r * 0.14, -0.25, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      break;
    }

    case 'square': {
      // Level 4: Pink Gummy Square
      const boxSize = r * 1.5;
      const corner = r * 0.3;
      const x0 = -boxSize / 2;
      const y0 = -boxSize / 2;

      // Rounded rectangle
      ctx.beginPath();
      ctx.roundRect(x0, y0, boxSize, boxSize, corner);

      const grad = ctx.createLinearGradient(x0, y0, x0 + boxSize, y0 + boxSize);
      grad.addColorStop(0, '#f48fb1');
      grad.addColorStop(0.5, '#ec407a');
      grad.addColorStop(1, '#c2185b');
      ctx.fillStyle = grad;
      ctx.fill();

      // Inner glowing border
      ctx.strokeStyle = '#f8bbd0';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Inner square inset
      ctx.beginPath();
      ctx.roundRect(x0 + 4, y0 + 4, boxSize - 8, boxSize - 8, corner * 0.6);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.fill();

      // Top-left gloss sheen
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.3, -r * 0.35, r * 0.22, r * 0.12, -0.4, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      break;
    }

    case 'star': {
      // Level 5: Orange Star Candy (6 spikes)
      drawStar(ctx, 0, 0, 6, r * 0.95, r * 0.52);

      const grad = ctx.createRadialGradient(0, -r * 0.2, r * 0.1, 0, 0, r);
      grad.addColorStop(0, '#ffe082');
      grad.addColorStop(0.4, '#ff9800');
      grad.addColorStop(1, '#e65100');
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.strokeStyle = '#f57c00';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Inner star ring
      drawStar(ctx, 0, 0, 6, r * 0.55, r * 0.3);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.fill();

      // Star gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.arc(-r * 0.2, -r * 0.2, r * 0.18, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.fill();
      break;
    }

    case 'swirl-green': {
      // Level 6: Green Peppermint Swirl
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.88, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      // Draw spiral wedges
      const wedges = 8;
      for (let i = 0; i < wedges; i += 2) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, r * 0.88, (i * Math.PI * 2) / wedges, ((i + 1) * Math.PI * 2) / wedges);
        ctx.closePath();
        ctx.fillStyle = '#43a047';
        ctx.fill();
      }

      // Outer rim
      ctx.strokeStyle = '#2e7d32';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Center peppermint button
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.24, 0, Math.PI * 2);
      ctx.fillStyle = '#81c784';
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Glossy crescent
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.28, -r * 0.28, r * 0.24, r * 0.12, -0.7, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
      ctx.fill();
      break;
    }

    case 'swirl-orange': {
      // Level 7: Orange Caramel Wheel
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.9, 0, Math.PI * 2);
      ctx.fillStyle = '#ffecb3';
      ctx.fill();

      const wedges = 10;
      for (let i = 0; i < wedges; i += 2) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, r * 0.9, (i * Math.PI * 2) / wedges, ((i + 1) * Math.PI * 2) / wedges);
        ctx.closePath();
        ctx.fillStyle = '#fb8c00';
        ctx.fill();
      }

      ctx.strokeStyle = '#ef6c00';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, r * 0.25, 0, Math.PI * 2);
      ctx.fillStyle = '#ffd54f';
      ctx.fill();

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.28, -r * 0.28, r * 0.24, r * 0.12, -0.7, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      break;
    }

    case 'spotted': {
      // Level 8: Pink Spotted Candy
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.88, 0, Math.PI * 2);
      const grad = ctx.createRadialGradient(-r * 0.2, -r * 0.2, r * 0.1, 0, 0, r * 0.9);
      grad.addColorStop(0, '#f8bbd0');
      grad.addColorStop(0.5, '#ec407a');
      grad.addColorStop(1, '#880e4f');
      ctx.fillStyle = grad;
      ctx.fill();

      // White candy polka dots
      const dots = [
        { x: -r * 0.4, y: 0 },
        { x: r * 0.4, y: 0 },
        { x: 0, y: -r * 0.4 },
        { x: 0, y: r * 0.4 },
        { x: -r * 0.25, y: r * 0.25 },
        { x: r * 0.25, y: -r * 0.25 }
      ];
      ctx.fillStyle = '#ffffff';
      dots.forEach((dot) => {
        ctx.beginPath();
        ctx.arc(dot.x, dot.y, r * 0.1, 0, Math.PI * 2);
        ctx.fill();
      });

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.arc(-r * 0.3, -r * 0.3, r * 0.22, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      break;
    }

    case 'flower': {
      // Level 9: Emerald Flower Swirl (4 petals)
      const petals = 4;
      for (let i = 0; i < petals; i++) {
        const ang = (i * Math.PI * 2) / petals;
        const px = Math.cos(ang) * r * 0.45;
        const py = Math.sin(ang) * r * 0.45;
        ctx.beginPath();
        ctx.arc(px, py, r * 0.48, 0, Math.PI * 2);
        ctx.fillStyle = '#43a047';
        ctx.fill();
      }
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.38, 0, Math.PI * 2);
      ctx.fillStyle = '#c8e6c9';
      ctx.fill();
      ctx.strokeStyle = '#2e7d32';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.arc(-r * 0.2, -r * 0.2, r * 0.18, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.fill();
      break;
    }

    case 'jewel': {
      // Level 10: Purple Jewel Star
      drawStar(ctx, 0, 0, 5, r * 0.95, r * 0.55);
      const grad = ctx.createLinearGradient(-r, -r, r, r);
      grad.addColorStop(0, '#e1bee7');
      grad.addColorStop(0.5, '#8e24aa');
      grad.addColorStop(1, '#4a148c');
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.strokeStyle = '#ce93d8';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Facet center
      drawStar(ctx, 0, 0, 5, r * 0.4, r * 0.2);
      ctx.fillStyle = '#f3e5f5';
      ctx.fill();
      break;
    }

    case 'heart': {
      // Level 11: Ruby Heart
      ctx.beginPath();
      const topY = -r * 0.5;
      ctx.moveTo(0, topY + r * 0.3);
      ctx.bezierCurveTo(-r * 0.6, -r * 0.8, -r * 1.05, topY + r * 0.5, 0, r * 0.88);
      ctx.bezierCurveTo(r * 1.05, topY + r * 0.5, r * 0.6, -r * 0.8, 0, topY + r * 0.3);
      ctx.closePath();

      const grad = ctx.createRadialGradient(-r * 0.2, -r * 0.2, r * 0.1, 0, 0, r);
      grad.addColorStop(0, '#ff80ab');
      grad.addColorStop(0.5, '#e91e63');
      grad.addColorStop(1, '#880e4f');
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.strokeStyle = '#c2185b';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.3, -r * 0.25, r * 0.22, r * 0.12, -0.4, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.fill();
      break;
    }

    case 'rainbow': {
      // Special 99: Rainbow Lollipop
      const rings = [
        { color: '#f44336', radius: r * 0.9 },
        { color: '#ff9800', radius: r * 0.75 },
        { color: '#ffeb3b', radius: r * 0.6 },
        { color: '#4caf50', radius: r * 0.45 },
        { color: '#2196f3', radius: r * 0.3 },
        { color: '#9c27b0', radius: r * 0.18 }
      ];
      rings.forEach((ring) => {
        ctx.beginPath();
        ctx.arc(0, 0, ring.radius, 0, Math.PI * 2);
        ctx.fillStyle = ring.color;
        ctx.fill();
      });

      // Rainbow star center
      drawStar(ctx, 0, 0, 5, r * 0.18, r * 0.08);
      ctx.fillStyle = '#fff';
      ctx.fill();

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.3, -r * 0.3, r * 0.25, r * 0.12, -0.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.fill();
      break;
    }

    case 'bomb': {
      // Special 100: Donut Bomb
      // Outer dough
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.9, 0, Math.PI * 2);
      ctx.fillStyle = '#bcaaa4';
      ctx.fill();

      // Chocolate icing
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.78, 0, Math.PI * 2);
      ctx.fillStyle = '#4e342e';
      ctx.fill();

      // Center donut hole
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.28, 0, Math.PI * 2);
      ctx.fillStyle = '#3e2723';
      ctx.fill();

      // Donut Sprinkles
      const sprinkleColors = ['#ff4081', '#ffeb3b', '#00e676', '#40c4ff', '#ffffff'];
      for (let i = 0; i < 8; i++) {
        const ang = (i * Math.PI * 2) / 8 + 0.2;
        const dist = r * 0.54;
        const sx = Math.cos(ang) * dist;
        const sy = Math.sin(ang) * dist;
        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(ang + 0.5);
        ctx.fillStyle = sprinkleColors[i % sprinkleColors.length];
        ctx.fillRect(-r * 0.1, -r * 0.04, r * 0.2, r * 0.08);
        ctx.restore();
      }

      // Gloss
      ctx.shadowColor = 'transparent';
      ctx.beginPath();
      ctx.ellipse(-r * 0.32, -r * 0.32, r * 0.22, r * 0.1, -0.6, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.fill();
      break;
    }

    default: {
      // Default sphere
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.85, 0, Math.PI * 2);
      ctx.fillStyle = def.color;
      ctx.fill();
      break;
    }
  }

  ctx.restore();
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number
) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
}
