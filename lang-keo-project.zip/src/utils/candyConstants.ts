import { CandyDef } from '../types/game';

export const CANDY_DEFS: Record<number, CandyDef> = {
  1: {
    level: 1,
    name: 'Yellow Bean',
    icon: '🟡',
    color: '#ffc107',
    shape: 'bean',
    scoreValue: 100,
    starBonus: 10
  },
  2: {
    level: 2,
    name: 'Purple Gumdrop',
    icon: '🟣',
    color: '#ba68c8',
    shape: 'cone',
    scoreValue: 250,
    starBonus: 25
  },
  3: {
    level: 3,
    name: 'Blue Oval',
    icon: '🔵',
    color: '#29b6f6',
    shape: 'oval',
    scoreValue: 500,
    starBonus: 50
  },
  4: {
    level: 4,
    name: 'Pink Square',
    icon: '⏹️',
    color: '#f06292',
    shape: 'square',
    scoreValue: 1000,
    starBonus: 100
  },
  5: {
    level: 5,
    name: 'Orange Star',
    icon: '⭐',
    color: '#ffa726',
    shape: 'star',
    scoreValue: 2000,
    starBonus: 250
  },
  6: {
    level: 6,
    name: 'Green Swirl',
    icon: '🟢',
    color: '#66bb6a',
    shape: 'swirl-green',
    scoreValue: 4000,
    starBonus: 1000
  },
  7: {
    level: 7,
    name: 'Orange Swirl',
    icon: '🟠',
    color: '#ff9800',
    shape: 'swirl-orange',
    scoreValue: 8000,
    starBonus: 3000
  },
  8: {
    level: 8,
    name: 'Pink Spotted',
    icon: '🌸',
    color: '#ec407a',
    shape: 'spotted',
    scoreValue: 15000,
    starBonus: 5000
  },
  9: {
    level: 9,
    name: 'Green Flower',
    icon: '🍀',
    color: '#4caf50',
    shape: 'flower',
    scoreValue: 30000,
    starBonus: 10000
  },
  10: {
    level: 10,
    name: 'Purple Star',
    icon: '🔮',
    color: '#9c27b0',
    shape: 'jewel',
    scoreValue: 60000,
    starBonus: 20000
  },
  11: {
    level: 11,
    name: 'Pink Heart',
    icon: '💖',
    color: '#e91e63',
    shape: 'heart',
    scoreValue: 100000,
    starBonus: 50000
  },
  99: {
    level: 99,
    name: 'Rainbow Candy',
    icon: '🍭',
    color: '#ff4081',
    shape: 'rainbow',
    scoreValue: 5000,
    starBonus: 500
  },
  100: {
    level: 100,
    name: 'Candy Bomb',
    icon: '🍩',
    color: '#8d6e63',
    shape: 'bomb',
    scoreValue: 5000,
    starBonus: 500
  }
};

export const MAX_STANDARD_LEVEL = 11;

export const BREAKDOWN_LEVELS = [6, 7, 8, 9, 10, 11]; // Levels shown on game over score card
