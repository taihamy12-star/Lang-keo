import { Village } from '../types/game';

export const INITIAL_VILLAGES: Village[] = [
  {
    id: 1,
    name: 'Sweet Meadows',
    title: 'Village 1',
    image: '/src/assets/images/village_cottage_1791124751263.jpg',
    cost: 0,
    isUnlocked: true,
    initialItems: 3,
    wildMana: 100,
    extraScorePercent: 0,
    bgTheme: 'meadows'
  },
  {
    id: 2,
    name: 'Gingerbread Haven',
    title: 'Village 2',
    image: '/src/assets/images/village_chalet_1791124763597.jpg',
    cost: 20000,
    isUnlocked: false,
    initialItems: 3,
    wildMana: 110,
    extraScorePercent: 5,
    bgTheme: 'gingerbread'
  },
  {
    id: 3,
    name: 'Peppermint Castle',
    title: 'Village 3',
    image: '/src/assets/images/village_castle_1791124775866.jpg',
    cost: 50000,
    isUnlocked: false,
    initialItems: 4,
    wildMana: 125,
    extraScorePercent: 10,
    bgTheme: 'peppermint'
  }
];
