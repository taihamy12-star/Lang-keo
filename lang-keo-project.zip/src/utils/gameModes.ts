import { GameMode, GameModeId } from '../types/game';

export const GAME_MODES: Record<GameModeId, GameMode> = {
  EASY: {
    id: 'EASY',
    name: 'Easy / Relaxing',
    nameVn: 'Thong Thả',
    badge: 'Dễ (1 Kẹo)',
    icon: '🌱',
    spawnPerTurn: 1,
    initialCandies: 8,
    spawnLevels: [1, 1, 1, 2],
    scoreMultiplier: 1.0,
    hasTimer: false,
    description: 'Mỗi lượt chỉ rơi 1 viên kẹo cấp thấp. Thích hợp thư giãn và tạo chuỗi gộp khổng lồ.',
    color: '#4caf50'
  },
  CLASSIC: {
    id: 'CLASSIC',
    name: 'Classic Standard',
    nameVn: 'Cổ Điển',
    badge: 'Chuẩn (1 Kẹo)',
    icon: '⭐',
    spawnPerTurn: 1,
    initialCandies: 10,
    spawnLevels: [1, 1, 2, 2, 3],
    scoreMultiplier: 1.2,
    hasTimer: false,
    description: 'Chế độ chuẩn kinh điển nguyên bản. Tốc độ cân bằng và độ khó vừa phải.',
    color: '#0288d1'
  },
  HARD: {
    id: 'HARD',
    name: 'Candy Influx',
    nameVn: 'Kẹo Đổ Bộ',
    badge: 'Khó (2 Kẹo/Lượt)',
    icon: '🔥',
    spawnPerTurn: 2,
    initialCandies: 12,
    spawnLevels: [1, 1, 2, 2, 3, 4],
    scoreMultiplier: 1.6,
    hasTimer: false,
    description: 'Mỗi lượt đi không gộp sẽ làm rơi 2 viên kẹo mới! Bàn cờ nhanh đầy hơn, nhân x1.6 điểm.',
    color: '#f57c00'
  },
  CHAOS: {
    id: 'CHAOS',
    name: 'Sweet Tempest',
    nameVn: 'Cơn Bão Kẹo',
    badge: 'Siêu Khó (3 Kẹo/Lượt)',
    icon: '⚡',
    spawnPerTurn: 3,
    initialCandies: 14,
    spawnLevels: [1, 2, 2, 3, 3, 4, 5],
    scoreMultiplier: 2.2,
    hasTimer: false,
    description: 'Bão kẹo rơi tới 3 viên sau mỗi bước không gộp! Yêu cầu tính toán cực kỳ chuẩn xác, nhân x2.2 điểm.',
    color: '#d81b60'
  },
  TIME_RUSH: {
    id: 'TIME_RUSH',
    name: 'Time Rush',
    nameVn: 'Chạy Đua Thời Gian',
    badge: 'Đua Tốc Độ (45s)',
    icon: '⏱️',
    spawnPerTurn: 2,
    initialCandies: 12,
    spawnLevels: [1, 1, 2, 2, 3],
    scoreMultiplier: 2.8,
    hasTimer: true,
    timerSeconds: 45,
    description: 'Khởi đầu với 45 giây! Mỗi lần gộp kẹo sẽ hồi thêm thời gian. Thưởng x2.8 lần điểm số và mưa sao.',
    color: '#9c27b0'
  }
};

export const GAME_MODE_LIST: GameMode[] = [
  GAME_MODES.EASY,
  GAME_MODES.CLASSIC,
  GAME_MODES.HARD,
  GAME_MODES.CHAOS,
  GAME_MODES.TIME_RUSH
];
