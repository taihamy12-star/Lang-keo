import confetti from 'canvas-confetti';

// Vivid candy palette colors
export const CANDY_CONFETTI_COLORS = [
  '#ff4081', // Hot Pink
  '#ffeb3b', // Bright Yellow
  '#00e5ff', // Neon Cyan
  '#76ff03', // Lime Green
  '#e040fb', // Purple Orchid
  '#ff9100', // Vivid Orange
  '#ffffff'  // Sugar White
];

export const GOLDEN_CONFETTI_COLORS = [
  '#ffd700', // Gold
  '#ffb300', // Amber
  '#ffea00', // Yellow
  '#ffffff', // Sparkle white
  '#ff80ab'  // Rose gold
];

/**
 * Fires a localized candy explosion at screen coordinates (0..1 normalized)
 */
export function triggerMergeExplosion(
  xRatio = 0.5,
  yRatio = 0.5,
  magnitude: 'large' | 'mega' | 'legendary' = 'large'
) {
  const clampX = Math.max(0.05, Math.min(0.95, xRatio));
  const clampY = Math.max(0.05, Math.min(0.95, yRatio));

  if (magnitude === 'large') {
    // 4-candy match or combo 2-3
    confetti({
      particleCount: 35,
      spread: 60,
      startVelocity: 25,
      origin: { x: clampX, y: clampY },
      colors: CANDY_CONFETTI_COLORS,
      ticks: 160,
      gravity: 0.9,
      scalar: 0.9,
      shapes: ['circle', 'square']
    });
  } else if (magnitude === 'mega') {
    // 5+ match, combo 4+, or high tier (>= 7)
    confetti({
      particleCount: 65,
      spread: 85,
      startVelocity: 35,
      origin: { x: clampX, y: clampY },
      colors: CANDY_CONFETTI_COLORS,
      ticks: 200,
      gravity: 0.8,
      scalar: 1.1,
      shapes: ['circle', 'square', 'star']
    });
    // Secondary delayed glitter wave
    setTimeout(() => {
      confetti({
        particleCount: 25,
        spread: 100,
        startVelocity: 20,
        origin: { x: clampX, y: clampY },
        colors: GOLDEN_CONFETTI_COLORS,
        ticks: 140,
        gravity: 0.6,
        scalar: 0.8,
        shapes: ['circle', 'star']
      });
    }, 120);
  } else {
    // Legendary tier (tier 10-11, Rainbow merge, or Combo 5+)
    confetti({
      particleCount: 90,
      spread: 120,
      startVelocity: 42,
      origin: { x: clampX, y: clampY },
      colors: ['#ff1744', '#00e5ff', '#ffea00', '#d500f9', '#76ff03', '#ffffff'],
      ticks: 260,
      gravity: 0.75,
      scalar: 1.25,
      shapes: ['star', 'circle']
    });
  }
}

/**
 * Fires celebratory twin cannon explosion for reaching a new high score
 */
export function triggerHighScoreCelebration() {
  const end = Date.now() + 1400;

  const frame = () => {
    // Left cannon
    confetti({
      particleCount: 6,
      angle: 60,
      spread: 55,
      origin: { x: 0.05, y: 0.85 },
      colors: GOLDEN_CONFETTI_COLORS,
      startVelocity: 45,
      ticks: 200,
      scalar: 1.1,
      shapes: ['star', 'circle', 'square']
    });
    // Right cannon
    confetti({
      particleCount: 6,
      angle: 120,
      spread: 55,
      origin: { x: 0.95, y: 0.85 },
      colors: CANDY_CONFETTI_COLORS,
      startVelocity: 45,
      ticks: 200,
      scalar: 1.1,
      shapes: ['star', 'circle', 'square']
    });

    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  };

  frame();
}

/**
 * Level up or star milestone celebratory burst
 */
export function triggerLevelUpConfetti() {
  confetti({
    particleCount: 50,
    spread: 75,
    origin: { x: 0.5, y: 0.4 },
    colors: ['#ffd700', '#ff80ab', '#00e5ff', '#ffffff'],
    startVelocity: 30,
    ticks: 180,
    scalar: 1.0,
    shapes: ['star', 'circle']
  });
}
