import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import '@fontsource/fredoka/400.css';
import '@fontsource/fredoka/600.css';
import '@fontsource/fredoka/700.css';
import '@fontsource/lilita-one/400.css';
import '@fontsource/sniglet/800.css';

createRoot(document.getElementById('root')!).render(<App />);
