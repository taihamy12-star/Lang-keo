import { useState, useEffect } from 'react';
import { TitleScreen } from './components/TitleScreen';
import { VillageSelectScreen } from './components/VillageSelectScreen';
import { GameScreen } from './components/GameScreen';
import { GameOverModal } from './components/GameOverModal';
import { GiftModal } from './components/GiftModal';
import { HelpModal } from './components/HelpModal';
import { StatsModal } from './components/StatsModal';
import { BoosterBuyModal } from './components/BoosterBuyModal';
import { CandyTiersModal } from './components/CandyTiersModal';
import { GameModeSelectModal } from './components/GameModeSelectModal';
import { Village, BoosterInventory, GameModeId, SavedGameState } from './types/game';
import { INITIAL_VILLAGES } from './utils/villageData';
import { GAME_MODES } from './utils/gameModes';
import { sounds } from './utils/audio';

type ViewMode = 'TITLE' | 'VILLAGES' | 'PLAY';
type ModalMode = 'GIFT' | 'HELP' | 'STATS' | 'BOOSTER_BUY' | 'GAME_OVER' | 'TIERS' | 'MODE_SELECT' | null;

export default function App() {
  const [view, setView] = useState<ViewMode>('TITLE');
  const [modal, setModal] = useState<ModalMode>(null);

  // Persistence
  const [selectedGameModeId, setSelectedGameModeId] = useState<GameModeId>(() => {
    const saved = localStorage.getItem('candy_village_game_mode') as GameModeId;
    return saved && GAME_MODES[saved] ? saved : 'CLASSIC';
  });

  const [savedGame, setSavedGame] = useState<SavedGameState | null>(() => {
    const saved = localStorage.getItem('candy_village_saved_game');
    if (saved) {
      try {
        const parsed: SavedGameState = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.board) && parsed.board.some((row) => row.some((c) => c !== null))) {
          return parsed;
        }
      } catch {
        return null;
      }
    }
    return null;
  });

  const [activeSession, setActiveSession] = useState<SavedGameState | null>(() => {
    const saved = localStorage.getItem('candy_village_saved_game');
    if (saved) {
      try {
        const parsed: SavedGameState = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.board) && parsed.board.some((row) => row.some((c) => c !== null))) {
          return parsed;
        }
      } catch {
        return null;
      }
    }
    return null;
  });

  const [lastGiftClaimDate, setLastGiftClaimDate] = useState<string>(() => {
    return localStorage.getItem('candy_village_last_gift_date') || '';
  });

  const [stars, setStars] = useState<number>(() => {
    const saved = localStorage.getItem('candy_village_stars');
    return saved ? parseInt(saved, 10) : 10000;
  });

  const [highScore, setHighScore] = useState<number>(() => {
    const saved = localStorage.getItem('candy_village_highscore');
    return saved ? parseInt(saved, 10) : 40480;
  });

  const [villages, setVillages] = useState<Village[]>(() => {
    const saved = localStorage.getItem('candy_village_villages');
    if (saved) {
      try {
        const parsed: Village[] = JSON.parse(saved);
        return INITIAL_VILLAGES.map((initial) => {
          const match = parsed.find((p) => p.id === initial.id);
          return match
            ? { ...initial, isUnlocked: match.isUnlocked }
            : initial;
        });
      } catch {
        return INITIAL_VILLAGES;
      }
    }
    return INITIAL_VILLAGES;
  });

  const [selectedVillageId, setSelectedVillageId] = useState<number>(() => {
    const saved = localStorage.getItem('candy_village_saved_game');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.villageId) return parsed.villageId;
      } catch {
        return 1;
      }
    }
    return 1;
  });

  const [boosters, setBoosters] = useState<BoosterInventory>(() => {
    const saved = localStorage.getItem('candy_village_boosters');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return { rainbow: 1, bomb: 1, spin: 1, undo: 1 };
      }
    }
    return { rainbow: 1, bomb: 1, spin: 1, undo: 1 };
  });

  const [totalMerges, setTotalMerges] = useState<number>(() => {
    const saved = localStorage.getItem('candy_village_total_merges');
    return saved ? parseInt(saved, 10) : 124;
  });

  const [highestCandyTier, setHighestCandyTier] = useState<number>(() => {
    const saved = localStorage.getItem('candy_village_highest_tier');
    return saved ? parseInt(saved, 10) : 6;
  });

  const [buyingBooster, setBuyingBooster] = useState<'rainbow' | 'bomb' | 'spin' | 'undo'>('bomb');

  // Game Over summary data
  const [gameOverData, setGameOverData] = useState<{
    score: number;
    candyStats: Record<number, number>;
    bonusStars: number;
    isNewHigh: boolean;
  }>({
    score: 0,
    candyStats: {},
    bonusStars: 0,
    isNewHigh: false
  });

  // Sound toggles
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('candy_village_stars', stars.toString());
  }, [stars]);

  useEffect(() => {
    localStorage.setItem('candy_village_highscore', highScore.toString());
  }, [highScore]);

  useEffect(() => {
    localStorage.setItem('candy_village_villages', JSON.stringify(villages));
  }, [villages]);

  useEffect(() => {
    localStorage.setItem('candy_village_boosters', JSON.stringify(boosters));
  }, [boosters]);

  useEffect(() => {
    localStorage.setItem('candy_village_total_merges', totalMerges.toString());
  }, [totalMerges]);

  useEffect(() => {
    localStorage.setItem('candy_village_highest_tier', highestCandyTier.toString());
  }, [highestCandyTier]);

  useEffect(() => {
    localStorage.setItem('candy_village_game_mode', selectedGameModeId);
  }, [selectedGameModeId]);

  const currentVillage = villages.find((v) => v.id === selectedVillageId) || villages[0];
  const activeGameMode = GAME_MODES[selectedGameModeId] || GAME_MODES.CLASSIC;

  const getTodayDateString = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const isGiftClaimedToday = lastGiftClaimDate === getTodayDateString();

  const readSavedGameFromStorage = (): SavedGameState | null => {
    const saved = localStorage.getItem('candy_village_saved_game');
    if (saved) {
      try {
        const parsed: SavedGameState = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.board) && parsed.board.some((row) => row.some((c) => c !== null))) {
          return parsed;
        }
      } catch {
        return null;
      }
    }
    return null;
  };

  const handleResumeGame = () => {
    const existing = readSavedGameFromStorage();
    if (existing) {
      if (existing.villageId) setSelectedVillageId(existing.villageId);
      if (existing.gameModeId) setSelectedGameModeId(existing.gameModeId);
      setActiveSession(existing);
    }
    setView('PLAY');
  };

  const handleNewGame = () => {
    localStorage.removeItem('candy_village_saved_game');
    setSavedGame(null);
    setActiveSession(null);
    setView('PLAY');
  };

  const handleSelectVillage = (vId: number) => {
    setSelectedVillageId(vId);
    const existing = readSavedGameFromStorage();
    if (existing && existing.villageId === vId) {
      setActiveSession(existing);
    } else {
      localStorage.removeItem('candy_village_saved_game');
      setSavedGame(null);
      setActiveSession(null);
    }
    setView('PLAY');
  };

  const handleGoHome = () => {
    setSavedGame(readSavedGameFromStorage());
    setView('TITLE');
  };

  const handleUnlockVillage = (vId: number) => {
    const target = villages.find((v) => v.id === vId);
    if (!target) return;
    if (stars >= target.cost) {
      sounds.playStarCoin();
      const newStars = stars - target.cost;
      setStars(newStars);
      setVillages((prev) =>
        prev.map((v) => (v.id === vId ? { ...v, isUnlocked: true } : v))
      );
    }
  };

  const handleClearSavedSession = () => {
    localStorage.removeItem('candy_village_saved_game');
    setSavedGame(null);
    setActiveSession(null);
  };

  const handleGameOver = (
    finalScore: number,
    stats: Record<number, number>,
    bonusStars: number
  ) => {
    let isNew = false;
    if (finalScore > highScore) {
      setHighScore(finalScore);
      isNew = true;
    }

    // Count merges
    const roundMerges = Object.values(stats).reduce((a, b) => a + b, 0);
    setTotalMerges((prev) => prev + roundMerges);

    // Track highest candy tier reached
    const createdTiers = Object.keys(stats).map(Number);
    if (createdTiers.length > 0) {
      const maxTier = Math.max(...createdTiers);
      if (maxTier > highestCandyTier) {
        setHighestCandyTier(maxTier);
      }
    }

    handleClearSavedSession();

    setGameOverData({
      score: finalScore,
      candyStats: stats,
      bonusStars,
      isNewHigh: isNew
    });
    setModal('GAME_OVER');
  };

  return (
    <div className="min-h-screen w-full bg-[#1b0f19] flex items-center justify-center p-0 sm:p-4 overflow-hidden">

      {/* Whimsical outer ambient lighting */}
      <div className="fixed inset-0 bg-radial from-[#6a1b9a]/20 via-transparent to-black pointer-events-none" />

      {/* Game Frame matching 400x710 resolution */}
      <div className="relative w-full sm:w-[400px] h-[100dvh] sm:h-[720px] max-h-[100dvh] sm:max-h-[730px] bg-[#5d3453] sm:rounded-[28px] border-0 sm:border-4 border-[#ff80ab] shadow-[0_15px_40px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col items-center">
        {/* Active Screen View */}
        {view === 'TITLE' && (
          <TitleScreen
            stars={stars}
            gameMode={activeGameMode}
            isGiftClaimedToday={isGiftClaimedToday}
            savedGame={savedGame}
            onResume={handleResumeGame}
            onNewGame={handleNewGame}
            onOpenVillages={() => setView('VILLAGES')}
            onOpenCandyTiers={() => setModal('TIERS')}
            onOpenGameModes={() => setModal('MODE_SELECT')}
            onOpenGift={() => setModal('GIFT')}
            onOpenStats={() => setModal('STATS')}
            onOpenHelp={() => setModal('HELP')}
            soundEnabled={soundEnabled}
            musicEnabled={musicEnabled}
            onToggleSound={() => {
              const enabled = sounds.toggleSound();
              setSoundEnabled(enabled);
            }}
            onToggleMusic={() => {
              const enabled = sounds.toggleMusic();
              setMusicEnabled(enabled);
            }}
          />
        )}

        {view === 'VILLAGES' && (
          <VillageSelectScreen
            villages={villages}
            currentVillageId={selectedVillageId}
            stars={stars}
            onBack={() => setView('TITLE')}
            onSelectVillage={handleSelectVillage}
            onUnlockVillage={handleUnlockVillage}
            onOpenShop={() => {
              setBuyingBooster('bomb');
              setModal('BOOSTER_BUY');
            }}
          />
        )}

        {view === 'PLAY' && (
          <GameScreen
            village={currentVillage}
            gameMode={activeGameMode}
            stars={stars}
            highScore={highScore}
            boosters={boosters}
            savedSession={activeSession}
            onClearSavedSession={handleClearSavedSession}
            onUpdateStars={setStars}
            onUpdateBoosters={setBoosters}
            onHome={handleGoHome}
            onHelp={() => setModal('HELP')}
            onOpenCandyTiers={() => setModal('TIERS')}
            onChangeGameMode={() => setModal('MODE_SELECT')}
            onGameOver={handleGameOver}
            onOpenBoosterShop={(type) => {
              setBuyingBooster(type);
              setModal('BOOSTER_BUY');
            }}
          />
        )}

        {/* Modals */}
        {modal === 'GIFT' && (
          <GiftModal
            isClaimedToday={isGiftClaimedToday}
            onClose={() => setModal(null)}
            onClaim={(reward) => {
              const today = getTodayDateString();
              setLastGiftClaimDate(today);
              localStorage.setItem('candy_village_last_gift_date', today);
              if (reward.type === 'stars') {
                setStars((s) => s + reward.amount);
              } else if (reward.type === 'rainbow') {
                setBoosters((b) => ({ ...b, rainbow: b.rainbow + reward.amount }));
              } else if (reward.type === 'bomb') {
                setBoosters((b) => ({ ...b, bomb: b.bomb + reward.amount }));
              }
              setModal(null);
            }}
          />
        )}

        {modal === 'HELP' && (
          <HelpModal
            onClose={() => setModal(null)}
            onOpenCandyTiers={() => setModal('TIERS')}
          />
        )}

        {modal === 'TIERS' && (
          <CandyTiersModal
            highestCandyTier={highestCandyTier}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'MODE_SELECT' && (
          <GameModeSelectModal
            currentModeId={selectedGameModeId}
            onSelectMode={(modeId) => {
              setSelectedGameModeId(modeId);
              if (savedGame && savedGame.gameModeId !== modeId) {
                // If changing mode for next game, clear old mode session
                handleClearSavedSession();
              }
            }}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'STATS' && (
          <StatsModal
            highScore={highScore}
            totalMerges={totalMerges}
            unlockedVillagesCount={villages.filter((v) => v.isUnlocked).length}
            totalVillagesCount={villages.length}
            highestCandyTier={highestCandyTier}
            stars={stars}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'BOOSTER_BUY' && (
          <BoosterBuyModal
            boosterType={buyingBooster}
            stars={stars}
            onClose={() => setModal(null)}
            onBuy={(type, cost) => {
              if (stars >= cost) {
                sounds.playStarCoin();
                setStars((s) => s - cost);
                setBoosters((b) => ({ ...b, [type]: b[type] + 1 }));
                setModal(null);
              }
            }}
          />
        )}

        {modal === 'GAME_OVER' && (
          <GameOverModal
            score={gameOverData.score}
            highScore={highScore}
            isNewHigh={gameOverData.isNewHigh}
            candyStats={gameOverData.candyStats}
            totalBonusStars={gameOverData.bonusStars}
            onRestart={() => {
              handleNewGame();
              setModal(null);
            }}
            onStats={() => setModal('STATS')}
            onHome={() => {
              setView('TITLE');
              setModal(null);
            }}
          />
        )}
      </div>
    </div>
  );
}
