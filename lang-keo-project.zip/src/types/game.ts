export type GameModeId = 'EASY' | 'CLASSIC' | 'HARD' | 'CHAOS' | 'TIME_RUSH';

export interface GameMode {
  id: GameModeId;
  name: string;
  nameVn: string;
  badge: string;
  icon: string;
  spawnPerTurn: number;
  initialCandies: number;
  spawnLevels: number[];
  scoreMultiplier: number;
  hasTimer: boolean;
  timerSeconds?: number;
  description: string;
  color: string;
}

export interface CandyDef {
  level: number;
  name: string;
  icon: string;
  color: string;
  shape: 'bean' | 'cone' | 'oval' | 'square' | 'star' | 'swirl-green' | 'swirl-orange' | 'spotted' | 'flower' | 'jewel' | 'heart' | 'rainbow' | 'bomb';
  scoreValue: number;
  starBonus: number;
}

export interface BoardCell {
  level: number; // 1-11 standard, 99 for rainbow, 100 for bomb
  id: string;
  scale?: number;
  isMerging?: boolean;
}

export type GridCoord = { r: number; c: number };

export interface Village {
  id: number;
  name: string;
  title: string;
  image: string;
  cost: number;
  isUnlocked: boolean;
  initialItems: number;
  wildMana: number;
  extraScorePercent: number;
  bgTheme: string;
}

export interface BoosterInventory {
  rainbow: number;
  bomb: number;
  spin: number;
  undo: number;
}

export interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  color?: string;
  createdAt: number;
}

export interface SparkleParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
}

export interface HighScoreRecord {
  score: number;
  date: string;
  villageName: string;
}

export interface SavedGameState {
  board: (BoardCell | null)[][];
  score: number;
  progress: number;
  queue: number[];
  candyStats: Record<number, number>;
  totalMerges: number;
  timeLeft: number;
  villageId: number;
  gameModeId: GameModeId;
  savedAt: number;
}
