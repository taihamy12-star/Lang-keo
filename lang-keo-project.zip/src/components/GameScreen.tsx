import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Home, HelpCircle, X, Plus } from 'lucide-react';
import { BoardCell, FloatingText, SparkleParticle, Village, BoosterInventory, GameMode, SavedGameState } from '../types/game';
import { CANDY_DEFS, MAX_STANDARD_LEVEL } from '../utils/candyConstants';
import { drawCheckerboard, drawCandy } from '../utils/candyRenderer';
import { sounds } from '../utils/audio';
import { triggerMergeExplosion, triggerHighScoreCelebration, triggerLevelUpConfetti } from '../utils/confettiEffects';

const GRID_SIZE = 6;
const MAX_PROGRESS = 120;

interface GameScreenProps {
  village: Village;
  gameMode: GameMode;
  stars: number;
  highScore: number;
  boosters: BoosterInventory;
  savedSession?: SavedGameState | null;
  onClearSavedSession?: () => void;
  onUpdateStars: (newStars: number) => void;
  onUpdateBoosters: (newBoosters: BoosterInventory) => void;
  onHome: () => void;
  onHelp: () => void;
  onOpenCandyTiers: () => void;
  onChangeGameMode?: () => void;
  onGameOver: (score: number, candyStats: Record<number, number>, bonusStars: number) => void;
  onOpenBoosterShop: (type: 'rainbow' | 'bomb' | 'spin' | 'undo') => void;
}

interface PopEffect {
  id: string;
  r: number;
  c: number;
  level: number;
  type: 'spawn' | 'merge';
}

export const GameScreen: React.FC<GameScreenProps> = ({
  village,
  gameMode,
  stars,
  highScore,
  boosters,
  savedSession,
  onClearSavedSession,
  onUpdateStars,
  onUpdateBoosters,
  onHome,
  onHelp,
  onOpenCandyTiers,
  onChangeGameMode,
  onGameOver,
  onOpenBoosterShop
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isFirstMountRef = useRef(true);

  // Game state
  const [board, setBoard] = useState<(BoardCell | null)[][]>(() => {
    if (savedSession && savedSession.board && savedSession.board.length === GRID_SIZE) {
      return savedSession.board;
    }
    return Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(null));
  });
  const [historyBoard, setHistoryBoard] = useState<(BoardCell | null)[][] | null>(null);
  const [historyScore, setHistoryScore] = useState<number>(0);

  const [selectedCell, setSelectedCell] = useState<{ r: number; c: number } | null>(null);
  const [isQueuePlatterSelected, setIsQueuePlatterSelected] = useState<boolean>(false);
  const [activeBooster, setActiveBooster] = useState<'rainbow' | 'bomb' | null>(null);

  const [score, setScore] = useState<number>(() => {
    return savedSession ? savedSession.score : 0;
  });
  const [progress, setProgress] = useState<number>(() => {
    return savedSession ? savedSession.progress : 32;
  });
  const [queue, setQueue] = useState<number[]>(() => {
    if (savedSession && savedSession.queue && savedSession.queue.length > 0) {
      return savedSession.queue;
    }
    const pool = gameMode.spawnLevels || [1, 1, 2, 2, 3];
    return [pool[0] || 1, pool[1] || 2, pool[0] || 1, pool[2] || 3];
  });
  const [candyStats, setCandyStats] = useState<Record<number, number>>(() => {
    return savedSession && savedSession.candyStats ? savedSession.candyStats : {};
  });
  const [totalMerges, setTotalMerges] = useState<number>(() => {
    return savedSession ? savedSession.totalMerges : 0;
  });
  const [timeLeft, setTimeLeft] = useState<number>(() => {
    return savedSession && gameMode.hasTimer && typeof savedSession.timeLeft === 'number'
      ? savedSession.timeLeft
      : (gameMode.timerSeconds || 45);
  });

  // Visual effects & CSS animations
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [popEffects, setPopEffects] = useState<PopEffect[]>([]);
  const spawnTimestampsRef = useRef<Map<string, number>>(new Map());
  const particlesRef = useRef<SparkleParticle[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  // Stable refs for callbacks inside timer loop
  const scoreRef = useRef(score);
  scoreRef.current = score;
  const candyStatsRef = useRef(candyStats);
  candyStatsRef.current = candyStats;
  const totalMergesRef = useRef(totalMerges);
  totalMergesRef.current = totalMerges;
  const starsRef = useRef(stars);
  starsRef.current = stars;
  const timeLeftRef = useRef(timeLeft);
  timeLeftRef.current = timeLeft;
  const onGameOverRef = useRef(onGameOver);
  onGameOverRef.current = onGameOver;
  const onUpdateStarsRef = useRef(onUpdateStars);
  onUpdateStarsRef.current = onUpdateStars;
  const onClearSavedSessionRef = useRef(onClearSavedSession);
  onClearSavedSessionRef.current = onClearSavedSession;
  const hasTriggeredHighScoreRef = useRef(savedSession ? savedSession.score > highScore : false);

  // Trigger CSS pulse / pop animation on candy spawn or merge
  const triggerPop = useCallback((r: number, c: number, level: number, type: 'spawn' | 'merge') => {
    const id = `pop_${r}_${c}_${Date.now()}_${Math.random()}`;
    spawnTimestampsRef.current.set(`${r},${c}`, Date.now());
    setPopEffects((prev) => [
      ...prev.filter((p) => !(p.r === r && p.c === c)),
      { id, r, c, level, type }
    ]);
    setTimeout(() => {
      setPopEffects((prev) => prev.filter((p) => p.id !== id));
    }, 620);
  }, []);

  // Initialize board on village or gameMode change
  useEffect(() => {
    if (isFirstMountRef.current) {
      isFirstMountRef.current = false;
      if (!savedSession || !savedSession.board || !savedSession.board.some((row) => row.some((c) => c !== null))) {
        initNewGame();
      }
      return;
    }
    initNewGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [village.id, gameMode.id]);

  // Auto-save game state to localStorage whenever board or critical game metrics change
  useEffect(() => {
    const hasCandies = board.some((row) => row.some((cell) => cell !== null));
    if (!hasCandies) return;

    const stateToSave: SavedGameState = {
      board,
      score,
      progress,
      queue,
      candyStats,
      totalMerges,
      timeLeft,
      villageId: village.id,
      gameModeId: gameMode.id,
      savedAt: Date.now()
    };

    localStorage.setItem('candy_village_saved_game', JSON.stringify(stateToSave));
  }, [board, score, progress, queue, candyStats, totalMerges, timeLeft, village.id, gameMode.id]);

  // Timer loop for TIME_RUSH mode
  useEffect(() => {
    if (!gameMode.hasTimer) return;
    const interval = window.setInterval(() => {
      const nextTime = timeLeftRef.current - 1;
      if (nextTime <= 0) {
        clearInterval(interval);
        setTimeLeft(0);
        sounds.playGameOver();
        const currentScore = scoreRef.current;
        const currentMerges = totalMergesRef.current;
        const bonusStars = Math.max(50, Math.floor(currentScore / 15) + currentMerges * 10);
        onUpdateStarsRef.current(starsRef.current + bonusStars);
        localStorage.removeItem('candy_village_saved_game');
        if (onClearSavedSessionRef.current) {
          onClearSavedSessionRef.current();
        }
        onGameOverRef.current(currentScore, candyStatsRef.current, bonusStars);
      } else {
        setTimeLeft(nextTime);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [gameMode.hasTimer]);

  const initNewGame = () => {
    const newBoard: (BoardCell | null)[][] = Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill(null));

    // Initial candies based on gameMode & village perks
    const spawnCount = Math.min(26, Math.max(6, gameMode.initialCandies + village.initialItems - 3));
    const empties: { r: number; c: number }[] = [];
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        empties.push({ r, c });
      }
    }

    // Shuffle and pick initial locations
    empties.sort(() => Math.random() - 0.5);
    const pool = gameMode.spawnLevels || [1, 1, 2, 2, 3];
    for (let i = 0; i < spawnCount; i++) {
      const pos = empties[i];
      const lvl = pool[Math.floor(Math.random() * pool.length)];
      newBoard[pos.r][pos.c] = {
        level: lvl,
        id: `c_${pos.r}_${pos.c}_${Date.now()}_${Math.random()}`
      };
      // Trigger gentle entry pop for initial candies
      triggerPop(pos.r, pos.c, lvl, 'spawn');
    }

    setBoard(newBoard);
    setScore(0);
    setProgress(32);
    setHistoryBoard(null);
    setQueue([pool[0] || 1, pool[1] || 2, pool[0] || 1, pool[2] || 3]);
    setSelectedCell(null);
    setIsQueuePlatterSelected(false);
    setActiveBooster(null);
    setCandyStats({});
    setTimeLeft(gameMode.timerSeconds || 45);
    hasTriggeredHighScoreRef.current = false;
  };

  // Add floating message ("SWEET!", "+1010", etc.)
  const addFloatingText = (text: string, x: number, y: number, color = '#40c4ff') => {
    const id = `txt_${Date.now()}_${Math.random()}`;
    setFloatingTexts((prev) => [...prev, { id, text, x, y, color, createdAt: Date.now() }]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((t) => t.id !== id));
    }, 900);
  };

  // Emit sparkling particles at board coordinate
  const emitSparkles = (x: number, y: number, count = 15, baseColor = '#ffeb3b') => {
    const newParticles: SparkleParticle[] = [];
    const colors = [baseColor, '#ffffff', '#40c4ff', '#ff4081', '#76ff03'];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 3.5;
      newParticles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.2,
        size: 3 + Math.random() * 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        life: 1
      });
    }
    particlesRef.current.push(...newParticles);
  };

  // Check orthogonal connected matches
  const getMatches = (startR: number, startC: number, lvl: number, currentBoard: (BoardCell | null)[][]) => {
    const visited = Array(GRID_SIZE)
      .fill(false)
      .map(() => Array(GRID_SIZE).fill(false));
    const list: { r: number; c: number }[] = [];
    const queuePos: { r: number; c: number }[] = [{ r: startR, c: startC }];
    visited[startR][startC] = true;

    while (queuePos.length > 0) {
      const curr = queuePos.shift()!;
      list.push(curr);

      const dirs = [
        [-1, 0],
        [1, 0],
        [0, -1],
        [0, 1]
      ];
      for (const [dr, dc] of dirs) {
        const nr = curr.r + dr;
        const nc = curr.c + dc;
        if (nr >= 0 && nr < GRID_SIZE && nc >= 0 && nc < GRID_SIZE) {
          if (!visited[nr][nc] && currentBoard[nr][nc]) {
            const cellLvl = currentBoard[nr][nc]!.level;
            // Match same level OR rainbow candy (99)
            if (cellLvl === lvl || cellLvl === 99 || lvl === 99) {
              visited[nr][nc] = true;
              queuePos.push({ r: nr, c: nc });
            }
          }
        }
      }
    }
    return list;
  };

  // Spawn candies based on current game mode's spawnPerTurn
  const spawnCandiesForTurn = (currentBoard: (BoardCell | null)[][]) => {
    const count = gameMode.spawnPerTurn;
    const pool = gameMode.spawnLevels || [1, 1, 2, 2, 3];

    for (let s = 0; s < count; s++) {
      const empties: { r: number; c: number }[] = [];
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (!currentBoard[r][c]) empties.push({ r, c });
        }
      }

      if (empties.length === 0) break;

      const pos = empties[Math.floor(Math.random() * empties.length)];
      const nextLvl = s === 0 ? (queue[0] || 1) : pool[Math.floor(Math.random() * pool.length)];

      if (s === 0) {
        setQueue((prev) => {
          const rest = prev.slice(1);
          rest.push(pool[Math.floor(Math.random() * pool.length)]);
          return rest;
        });
      }

      currentBoard[pos.r][pos.c] = {
        level: nextLvl,
        id: `c_${pos.r}_${pos.c}_${Date.now()}_${s}`
      };

      // Trigger gentle CSS pulse / pop animation on new spawn
      triggerPop(pos.r, pos.c, nextLvl, 'spawn');
    }
  };

  // Cascade merge handler
  const processMergeCascade = async (
    targetR: number,
    targetC: number,
    boardState: (BoardCell | null)[][],
    comboCount = 1
  ): Promise<{ updatedBoard: (BoardCell | null)[][]; merged: boolean }> => {
    const cell = boardState[targetR][targetC];
    if (!cell) return { updatedBoard: boardState, merged: false };

    const lvl = cell.level;
    const matches = getMatches(targetR, targetC, lvl, boardState);

    if (matches.length >= 3) {
      // Clear matched neighbors
      matches.forEach((m) => {
        if (m.r !== targetR || m.c !== targetC) {
          boardState[m.r][m.c] = null;
        }
      });

      // Target upgrades to next level (or stays at 11)
      const nextLvl = Math.min(MAX_STANDARD_LEVEL, lvl === 99 ? 2 : lvl + 1);
      boardState[targetR][targetC] = {
        level: nextLvl,
        id: `c_${targetR}_${targetC}_${Date.now()}`
      };

      // Trigger gentle CSS pulse / pop animation on merge
      triggerPop(targetR, targetC, nextLvl, 'merge');

      // Calculate score & progress with mode multiplier
      const baseVal = (CANDY_DEFS[lvl]?.scoreValue || 200) * matches.length;
      const extraMultiplier = 1 + (village.extraScorePercent || 0) / 100;
      const modeMultiplier = gameMode.scoreMultiplier || 1.0;
      const earnedScore = Math.floor(baseVal * comboCount * extraMultiplier * modeMultiplier);

      const nextScore = score + earnedScore;
      setScore(nextScore);

      // Celebratory explosion when player achieves a new high score in-game
      if (highScore > 0 && nextScore > highScore && !hasTriggeredHighScoreRef.current) {
        hasTriggeredHighScoreRef.current = true;
        triggerHighScoreCelebration();
        sounds.playComboChime();
        addFloatingText('🏆 KỶ LỤC MỚI! (HIGH SCORE!)', 180, 100, '#ffd700');
      }

      // Celebratory particle explosion for large candy merge, high tiers, or combos
      const canvas = canvasRef.current;
      let originX = 0.5;
      let originY = 0.5;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        originX = (rect.left + (targetC + 0.5) * (rect.width / GRID_SIZE)) / window.innerWidth;
        originY = (rect.top + (targetR + 0.5) * (rect.height / GRID_SIZE)) / window.innerHeight;
      }

      if (matches.length >= 5 || comboCount >= 4 || nextLvl >= 9) {
        triggerMergeExplosion(originX, originY, 'mega');
      } else if (matches.length >= 4 || comboCount >= 3 || nextLvl >= 6) {
        triggerMergeExplosion(originX, originY, 'large');
      }

      setProgress((prev) => {
        const nextProg = prev + matches.length * 4;
        if (nextProg >= MAX_PROGRESS) {
          triggerLevelUpConfetti();
          sounds.playComboChime();
          onUpdateStars(stars + 500);
          addFloatingText('LEVEL UP! +500 ⭐', 180, 150, '#ffeb3b');
          return nextProg % MAX_PROGRESS;
        }
        return nextProg;
      });

      // Track statistics for Game Over breakdown
      setCandyStats((prev) => ({
        ...prev,
        [nextLvl]: (prev[nextLvl] || 0) + 1
      }));
      setTotalMerges((prev) => prev + 1);

      // Audio & Visual feedback
      sounds.playMerge(nextLvl, comboCount);

      const cellSize = 360 / GRID_SIZE;
      const pixelX = targetC * cellSize + cellSize / 2;
      const pixelY = targetR * cellSize + cellSize / 2;

      emitSparkles(pixelX, pixelY, 20);

      // Time recovery in Time Rush mode
      if (gameMode.hasTimer) {
        const bonus = matches.length * 2;
        addFloatingText(`+${bonus}s ⏱️`, pixelX, pixelY - 35, '#e040fb');
        setTimeLeft((prev) => Math.min(gameMode.timerSeconds || 60, prev + bonus));
      }

      // Sweet / Tasty voice phrases
      const compliments = ['SWEET!', 'TASTY!', 'DIVINE!', 'DELICIOUS!', 'COMBO!'];
      const textChoice = comboCount > 1 ? `COMBO x${comboCount}!` : compliments[(nextLvl + comboCount) % compliments.length];
      addFloatingText(textChoice, pixelX, pixelY - 15, '#ff4081');
      addFloatingText(`+${earnedScore}`, pixelX, pixelY + 15, '#ffeb3b');

      // Check cascading recursive merge after brief delay
      await new Promise((r) => setTimeout(r, 120));
      return processMergeCascade(targetR, targetC, boardState, comboCount + 1);
    }

    return { updatedBoard: boardState, merged: comboCount > 1 };
  };

  // Check if board has no empty tiles and no valid moves
  const checkGameOverCondition = (currentBoard: (BoardCell | null)[][]) => {
    let hasEmpty = false;
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (!currentBoard[r][c]) {
          hasEmpty = true;
          break;
        }
      }
      if (hasEmpty) break;
    }

    if (!hasEmpty) {
      sounds.playGameOver();
      const bonusStars = Math.max(50, Math.floor(score / 15) + totalMerges * 10);
      onUpdateStars(stars + bonusStars);
      localStorage.removeItem('candy_village_saved_game');
      if (onClearSavedSession) {
        onClearSavedSession();
      }
      onGameOver(score, candyStats, bonusStars);
    }
  };

  // Main board click interaction
  const handleBoardClick = async (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    const cellSize = canvas.width / GRID_SIZE;
    const c = Math.floor(clickX / cellSize);
    const r = Math.floor(clickY / cellSize);

    if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE) return;

    // Save previous state for Undo booster
    const boardClone = board.map((row) => row.map((cell) => (cell ? { ...cell } : null)));

    // Booster: Bomb click on cell
    if (activeBooster === 'bomb') {
      sounds.playBomb();
      setActiveBooster(null);
      setHistoryBoard(boardClone);
      setHistoryScore(score);

      // Blast 3x3
      const newBoard = board.map((row) => [...row]);
      let blastedCount = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const br = r + dr;
          const bc = c + dc;
          if (br >= 0 && br < GRID_SIZE && bc >= 0 && bc < GRID_SIZE) {
            if (newBoard[br][bc]) {
              newBoard[br][bc] = null;
              blastedCount++;
            }
          }
        }
      }
      emitSparkles(c * cellSize + cellSize / 2, r * cellSize + cellSize / 2, 35, '#ff1744');
      addFloatingText('BOOM! 💥', c * cellSize, r * cellSize, '#ff5252');
      setScore((s) => s + blastedCount * 500);
      setBoard(newBoard);
      onUpdateBoosters({ ...boosters, bomb: Math.max(0, boosters.bomb - 1) });
      return;
    }

    // Placing queue candy directly from saucer onto an empty tile
    if (isQueuePlatterSelected) {
      if (!board[r][c]) {
        sounds.playMove();
        setIsQueuePlatterSelected(false);
        setHistoryBoard(boardClone);
        setHistoryScore(score);

        const currentLvl = queue[0] || 1;
        setQueue((prev) => {
          const rest = prev.slice(1);
          const pool = [1, 1, 1, 2, 2, 3];
          rest.push(pool[Math.floor(Math.random() * pool.length)]);
          return rest;
        });

        const newBoard = board.map((row) => [...row]);
        newBoard[r][c] = { level: currentLvl, id: `c_${r}_${c}_${Date.now()}` };
        triggerPop(r, c, currentLvl, 'spawn');

        // Process potential merge
        const { updatedBoard } = await processMergeCascade(r, c, newBoard);
        setBoard([...updatedBoard]);
        checkGameOverCondition(updatedBoard);
      } else {
        // Tapped occupied tile, deselect platter
        setIsQueuePlatterSelected(false);
      }
      return;
    }

    // Booster: Rainbow drop on empty tile
    if (activeBooster === 'rainbow') {
      if (!board[r][c]) {
        sounds.playRainbow();
        setActiveBooster(null);
        setHistoryBoard(boardClone);
        setHistoryScore(score);

        const newBoard = board.map((row) => [...row]);
        newBoard[r][c] = { level: 99, id: `rainbow_${Date.now()}` };
        triggerPop(r, c, 99, 'spawn');

        onUpdateBoosters({ ...boosters, rainbow: Math.max(0, boosters.rainbow - 1) });
        const { updatedBoard } = await processMergeCascade(r, c, newBoard);
        setBoard([...updatedBoard]);
        checkGameOverCondition(updatedBoard);
      }
      return;
    }

    // Normal gameplay: Select candy
    if (board[r][c] && !selectedCell) {
      sounds.playTap();
      setSelectedCell({ r, c });
      return;
    }

    // Deselect if clicking the same candy
    if (selectedCell && selectedCell.r === r && selectedCell.c === c) {
      sounds.playTap();
      setSelectedCell(null);
      return;
    }

    // Click another candy -> switch selection
    if (selectedCell && board[r][c]) {
      sounds.playTap();
      setSelectedCell({ r, c });
      return;
    }

    // Move selected candy to empty cell
    if (selectedCell && !board[r][c]) {
      sounds.playMove();
      setHistoryBoard(boardClone);
      setHistoryScore(score);

      const newBoard = board.map((row) => [...row]);
      newBoard[r][c] = newBoard[selectedCell.r][selectedCell.c];
      newBoard[selectedCell.r][selectedCell.c] = null;
      setSelectedCell(null);

      // Process merge at destination
      const { updatedBoard, merged } = await processMergeCascade(r, c, newBoard);

      if (!merged) {
        // If move did not produce a match, spawn candies according to mode difficulty
        spawnCandiesForTurn(updatedBoard);
      }

      setBoard([...updatedBoard]);
      checkGameOverCondition(updatedBoard);
    }
  };

  // Booster Actions
  const handleUseBooster = (type: 'rainbow' | 'bomb' | 'spin' | 'undo') => {
    sounds.playTap();
    if (boosters[type] <= 0) {
      onOpenBoosterShop(type);
      return;
    }

    if (type === 'undo') {
      if (historyBoard) {
        sounds.playMove();
        setBoard(historyBoard);
        setScore(historyScore);
        setHistoryBoard(null);
        onUpdateBoosters({ ...boosters, undo: Math.max(0, boosters.undo - 1) });
        addFloatingText('UNDO! ↩️', 180, 180, '#29b6f6');
      } else {
        addFloatingText('No move to undo', 180, 180, '#fff');
      }
      return;
    }

    if (type === 'spin') {
      sounds.playComboChime();
      // Shuffle all low level candies (1-3)
      const newBoard = board.map((row) => [...row]);
      const lowCells: { r: number; c: number; level: number }[] = [];
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (newBoard[r][c] && newBoard[r][c]!.level <= 3) {
            lowCells.push({ r, c, level: newBoard[r][c]!.level });
          }
        }
      }

      if (lowCells.length > 1) {
        const levels = lowCells.map((l) => l.level).sort(() => Math.random() - 0.5);
        lowCells.forEach((cell, idx) => {
          newBoard[cell.r][cell.c] = {
            level: levels[idx],
            id: `c_${cell.r}_${cell.c}_${Date.now()}`
          };
        });
        setBoard(newBoard);
        emitSparkles(180, 180, 30, '#00e676');
        addFloatingText('SHUFFLED! 🪀', 160, 180, '#00e676');
        onUpdateBoosters({ ...boosters, spin: Math.max(0, boosters.spin - 1) });
      }
      return;
    }

    if (type === 'rainbow') {
      setActiveBooster('rainbow');
      addFloatingText('Tap empty square to place Rainbow! 🍭', 60, 180, '#ff4081');
    }

    if (type === 'bomb') {
      setActiveBooster('bomb');
      addFloatingText('Tap any candy to blast 3x3! 🍩', 80, 180, '#ff1744');
    }
  };

  // Canvas drawing loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Draw Checkerboard background
      drawCheckerboard(ctx, canvas.width, canvas.height, GRID_SIZE, selectedCell);

      // 2. Draw Candies
      const cellSize = canvas.width / GRID_SIZE;
      const candyRadius = cellSize / 2 - 6;

      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const item = board[r][c];
          if (item) {
            const cx = c * cellSize + cellSize / 2;
            const cy = r * cellSize + cellSize / 2;
            const isSelected = selectedCell && selectedCell.r === r && selectedCell.c === c;

            // Smooth gentle pop/pulse scale curve on spawn or merge
            const spawnTime = spawnTimestampsRef.current.get(`${r},${c}`);
            let popScale = 1;
            if (spawnTime) {
              const elapsed = Date.now() - spawnTime;
              if (elapsed < 480) {
                const t = elapsed / 480;
                if (t < 0.45) {
                  popScale = 0.25 + (t / 0.45) * 1.01; // 0.25 -> 1.26
                } else if (t < 0.7) {
                  popScale = 1.26 - ((t - 0.45) / 0.25) * 0.33; // 1.26 -> 0.93
                } else if (t < 0.88) {
                  popScale = 0.93 + ((t - 0.7) / 0.18) * 0.12; // 0.93 -> 1.05
                } else {
                  popScale = 1.05 - ((t - 0.88) / 0.12) * 0.05; // 1.05 -> 1.0
                }
              }
            }

            const scale = (isSelected ? 1.15 : 1) * popScale;
            drawCandy(ctx, cx, cy, item.level, candyRadius, scale);
          }
        }
      }

      // 3. Update & render particles
      const aliveParticles: SparkleParticle[] = [];
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.08; // Gravity
        p.alpha -= 0.025;
        p.size *= 0.96;

        if (p.alpha > 0.05 && p.size > 0.5) {
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          aliveParticles.push(p);
        }
      }
      particlesRef.current = aliveParticles;

      if (isRunning) {
        animationFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      isRunning = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [board, selectedCell]);

  // Current recipe display (e.g. 3 Yellow = 1 Purple)
  const currentIncoming = queue[0] || 1;
  const currentDef = CANDY_DEFS[currentIncoming] || CANDY_DEFS[1];
  const nextDef = CANDY_DEFS[Math.min(MAX_STANDARD_LEVEL, currentIncoming + 1)] || CANDY_DEFS[2];

  return (
    <div className="relative w-full h-full flex flex-col justify-between items-center bg-[#542d4a] select-none overflow-hidden">
      {/* Background chocolate wallpaper */}
      <img
        src="/src/assets/images/board_candy_bg_1791124737983.jpg"
        alt="Board Backdrop"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover opacity-75 pointer-events-none"
      />

      {/* Top Bar: Stars Pill, Mode Badge, Timer & Quit */}
      <div className="relative z-10 w-full px-3 pt-2 pb-1 flex justify-between items-center bg-black/25">
        <div className="flex items-center gap-1.5 flex-wrap max-w-[62%]">
          <span className="font-lilita text-xs text-pink-200 uppercase tracking-wider hidden sm:inline">
            {village.name}
          </span>

          {/* Mode Pill Button */}
          <button
            onClick={() => {
              sounds.playTap();
              if (onChangeGameMode) onChangeGameMode();
            }}
            className="flex items-center gap-1 px-2 py-0.5 rounded-full border border-white text-white font-lilita text-[10px] shadow-sm hover:brightness-110 active:scale-95 transition-all cursor-pointer"
            style={{ backgroundColor: gameMode.color }}
            title="Đổi Chế Độ Chơi (5 Chế Độ)"
          >
            <span>{gameMode.icon}</span>
            <span>{gameMode.badge}</span>
          </button>

          {/* Time Rush Timer if active */}
          {gameMode.hasTimer && (
            <div
              className={`flex items-center gap-1 px-2 py-0.5 rounded-full border border-white font-lilita text-[11px] shadow-sm ${
                timeLeft <= 10
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'bg-purple-700 text-yellow-300'
              }`}
            >
              <span>⏱️</span>
              <span>{timeLeft}s</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Star Counter Pill */}
          <div className="flex items-center bg-white border-3 border-[#ffcc00] rounded-full pl-2 pr-1.5 py-0.5 shadow-md">
            <span className="text-lg mr-1 -ml-1">⭐</span>
            <span className="font-lilita text-base tracking-wide text-amber-900 mr-2">
              {stars.toLocaleString()}
            </span>
            <button
              onClick={() => {
                sounds.playTap();
                onOpenBoosterShop('bomb');
              }}
              className="w-5 h-5 rounded-full bg-gradient-to-b from-[#e91e63] to-[#ad1457] text-white flex items-center justify-center font-bold text-xs active:scale-90"
              title="Get More Stars"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </button>
          </div>

          {/* Pause / Quit Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onHome();
            }}
            className="w-8 h-8 rounded-full bg-gradient-to-b from-[#ff1744] to-[#c2185b] border-2 border-white shadow-md flex items-center justify-center text-white active:scale-95 transition-transform"
            title="Exit to Village Menu"
          >
            <X className="w-5 h-5 stroke-[3]" />
          </button>
        </div>
      </div>

      {/* Header Panel: SCORE Banner + Candy Queue Platters */}
      <div className="relative z-10 w-[94%] score-panel-bg border-3 border-white rounded-2xl p-2 shadow-lg flex flex-col gap-1.5 my-1">
        <div className="flex items-center justify-between">
          {/* Left: Blue Striped SCORE Box */}
          <div className="flex flex-col items-start bg-gradient-to-b from-[#0288d1] to-[#01579b] border-2 border-white rounded-xl px-3 py-1 shadow-md">
            <span className="font-lilita text-xs tracking-wider text-cyan-200 leading-none">
              SCORE
            </span>
            <span className="font-lilita text-xl sm:text-2xl text-[#ffeb3b] drop-shadow-[0_2px_0_#d81b60] leading-tight">
              {score.toLocaleString()}
            </span>
          </div>

          {/* Center-Right: Candy Queue Saucers (Screenshot 1, 2, 7) */}
          <div className="flex items-center gap-2">
            {/* Big Platter: Current Candy ready to drop/spawn */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => {
                  sounds.playTap();
                  setIsQueuePlatterSelected(!isQueuePlatterSelected);
                }}
                className={`relative w-14 h-14 rounded-full bg-gradient-to-b from-white via-sky-100 to-sky-300 border-3 shadow-md flex items-center justify-center transition-all ${
                  isQueuePlatterSelected
                    ? 'border-[#ffeb3b] scale-110 shadow-[0_0_12px_#ffeb3b]'
                    : 'border-white hover:scale-105 active:scale-95'
                }`}
                title="Tap to select and place onto an empty square"
              >
                <span className="text-2xl">{currentDef.icon}</span>
                {isQueuePlatterSelected && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 border border-white rounded-full flex items-center justify-center text-[10px] text-amber-900 font-bold animate-ping" />
                )}
              </button>
              <span className="text-[10px] font-lilita text-pink-900 mt-0.5 font-bold">NEXT</span>
            </div>

            {/* Small Platters: Preview next 2 candies */}
            <div className="flex items-center gap-1">
              {queue.slice(1, 3).map((lvl, idx) => {
                const def = CANDY_DEFS[lvl] || CANDY_DEFS[1];
                return (
                  <div
                    key={idx}
                    className="w-10 h-10 rounded-full bg-gradient-to-b from-white to-sky-200 border-2 border-white shadow-inner flex items-center justify-center text-lg"
                  >
                    {def.icon}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sub-bar: Home, Help, Candy Tiers, Recipe */}
        <div className="w-full bg-white/90 rounded-full py-1 px-2.5 flex items-center justify-between border border-pink-300 shadow-sm">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                sounds.playTap();
                onHome();
              }}
              className="w-7 h-7 rounded-full bg-[#29b6f6] border-2 border-white flex items-center justify-center text-white shadow-sm active:scale-90"
              title="Về Trang Chủ"
            >
              <Home className="w-4 h-4 stroke-[2.5]" />
            </button>

            <button
              onClick={() => {
                sounds.playTap();
                onHelp();
              }}
              className="w-7 h-7 rounded-full bg-[#ff4081] border-2 border-white flex items-center justify-center text-white shadow-sm active:scale-90"
              title="Hướng Dẫn"
            >
              <HelpCircle className="w-4 h-4 stroke-[2.5]" />
            </button>

            {/* Candy Tiers Encyclopedia Button */}
            <button
              onClick={() => {
                sounds.playTap();
                onOpenCandyTiers();
              }}
              className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#ab47bc] to-[#ec407a] border-2 border-white flex items-center justify-center text-white text-xs shadow-sm active:scale-90 hover:scale-105 transition-all"
              title="Xem Cấp Bậc Kẹo (1 - 11)"
            >
              🍬
            </button>
          </div>

          {/* Dynamic Recipe Indicator - Clickable to open Candy Tiers */}
          <button
            onClick={() => {
              sounds.playTap();
              onOpenCandyTiers();
            }}
            className="font-lilita text-xs text-[#ad1457] bg-pink-100/70 hover:bg-pink-100 active:scale-95 border border-pink-200 rounded-full px-2 py-0.5 flex items-center gap-1 cursor-pointer transition-all shadow-2xs"
            title="Nhấn để xem toàn bộ bảng cấp bậc kẹo"
          >
            <span>3</span>
            <span>{currentDef.icon}</span>
            <span>=</span>
            <span>1</span>
            <span>{nextDef.icon}</span>
            <span className="text-[10px] text-pink-600 font-bold ml-0.5">📖</span>
          </button>

          {/* High Score Pill */}
          <div className="font-lilita text-[11px] text-[#0288d1]">
            BEST: {highScore.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Main 6x6 Canvas Game Board */}
      <div className="relative flex-1 w-full flex items-center justify-center my-1 px-2">
        <div className="relative p-1 bg-gradient-to-b from-[#795548] to-[#4e342e] rounded-xl border-4 border-[#a1887f] shadow-[0_8px_20px_rgba(0,0,0,0.6)]">
          <canvas
            ref={canvasRef}
            width={360}
            height={360}
            onClick={handleBoardClick}
            className="w-[330px] h-[330px] sm:w-[350px] sm:h-[350px] cursor-pointer rounded-lg touch-none"
          />

          {/* CSS Animation Overlay for newly spawned or merged candies */}
          <div className="absolute inset-1 pointer-events-none grid grid-cols-6 grid-rows-6">
            {popEffects.map((effect) => {
              const def = CANDY_DEFS[effect.level] || CANDY_DEFS[1];
              return (
                <div
                  key={effect.id}
                  style={{
                    gridColumnStart: effect.c + 1,
                    gridRowStart: effect.r + 1,
                  }}
                  className="relative flex items-center justify-center w-full h-full"
                >
                  {/* Expanding glowing pulse ring */}
                  <div
                    className={`absolute rounded-full pointer-events-none animate-candy-pulse-ring ${
                      effect.type === 'merge' ? 'w-12 h-12' : 'w-10 h-10'
                    }`}
                    style={{
                      borderColor: def.color,
                      boxShadow: `0 0 14px ${def.color}, inset 0 0 8px ${def.color}`,
                    }}
                  />

                  {/* Soft radial glow flare */}
                  <div
                    className="absolute w-12 h-12 rounded-full animate-candy-glow-flare pointer-events-none"
                    style={{
                      background: `radial-gradient(circle, ${def.color}aa 0%, transparent 70%)`,
                    }}
                  />

                  {/* Candy pop & gentle pulse feedback */}
                  <div className="relative flex items-center justify-center animate-candy-pop">
                    {/* Glowing sweet candy halo badge */}
                    <div
                      className={`rounded-full flex items-center justify-center shadow-lg border-2 border-white/95 ${
                        effect.type === 'merge' ? 'w-11 h-11 text-2xl' : 'w-9 h-9 text-lg'
                      }`}
                      style={{
                        backgroundColor: `${def.color}f0`,
                        boxShadow: `0 0 16px ${def.color}, 0 4px 10px rgba(0,0,0,0.4)`,
                      }}
                    >
                      <span>{def.icon}</span>
                    </div>

                    {/* Sparkle badge for merges */}
                    {effect.type === 'merge' && (
                      <span className="absolute -top-1.5 -right-1.5 text-xs animate-ping">
                        ✨
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Floating Text Overlays */}
          {floatingTexts.map((item) => (
            <div
              key={item.id}
              style={{ left: `${item.x}px`, top: `${item.y}px` }}
              className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2 font-lilita text-2xl text-candy-stroke animate-bounce z-30"
            >
              {item.text}
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Booster Panel (Striped Ribbon from Screenshots) */}
      <div className="relative z-10 w-[94%] candy-stripe-pink border-3 border-white rounded-2xl p-2 shadow-lg flex flex-col gap-1.5 mb-2">
        {/* Progress Bar (32/120) */}
        <div className="relative w-full h-4.5 bg-[#f57f17] rounded-full border-2 border-white overflow-hidden shadow-inner flex items-center">
          <div
            className="h-full bg-gradient-to-r from-[#ffee58] to-[#ff9800] transition-all duration-300 rounded-full"
            style={{ width: `${Math.min(100, (progress / MAX_PROGRESS) * 100)}%` }}
          />
          {/* Glossy reflection */}
          <div className="absolute top-0 inset-x-0 h-1.5 bg-white/40 rounded-t-full pointer-events-none" />
          <span className="absolute inset-0 flex items-center justify-center font-lilita text-[11px] text-white drop-shadow-[0_1px_1px_#000]">
            {progress}/{MAX_PROGRESS}
          </span>
        </div>

        {/* 4 Booster Buttons */}
        <div className="w-full flex justify-around items-center pt-0.5">
          {/* Booster 1: Rainbow Lollipop */}
          <button
            onClick={() => handleUseBooster('rainbow')}
            className={`relative w-12 h-12 rounded-xl border-2 border-white shadow-[0_3px_0_#01579b] flex items-center justify-center text-2xl active:translate-y-0.5 transition-all ${
              activeBooster === 'rainbow'
                ? 'bg-amber-300 border-amber-400 scale-105 shadow-[0_0_10px_#ffeb3b]'
                : 'bg-gradient-to-b from-[#29b6f6] to-[#0288d1]'
            }`}
            title="Rainbow Lollipop: Merges with any candy"
          >
            🍭
            <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#ff1744] text-white border border-white rounded-full flex items-center justify-center font-lilita text-[10px] font-bold shadow-sm">
              {boosters.rainbow > 0 ? boosters.rainbow : '+'}
            </div>
          </button>

          {/* Booster 2: Candy Bomb */}
          <button
            onClick={() => handleUseBooster('bomb')}
            className={`relative w-12 h-12 rounded-xl border-2 border-white shadow-[0_3px_0_#01579b] flex items-center justify-center text-2xl active:translate-y-0.5 transition-all ${
              activeBooster === 'bomb'
                ? 'bg-amber-300 border-amber-400 scale-105 shadow-[0_0_10px_#ffeb3b]'
                : 'bg-gradient-to-b from-[#29b6f6] to-[#0288d1]'
            }`}
            title="Donut Bomb: Blasts 3x3 tiles"
          >
            🍩
            <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#ff1744] text-white border border-white rounded-full flex items-center justify-center font-lilita text-[10px] font-bold shadow-sm">
              {boosters.bomb > 0 ? boosters.bomb : '+'}
            </div>
          </button>

          {/* Booster 3: Magic Whirly */}
          <button
            onClick={() => handleUseBooster('spin')}
            className="relative w-12 h-12 rounded-xl bg-gradient-to-b from-[#29b6f6] to-[#0288d1] border-2 border-white shadow-[0_3px_0_#01579b] flex items-center justify-center text-2xl active:translate-y-0.5 transition-all"
            title="Magic Whirly: Shuffles low-level candies"
          >
            🪀
            <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#ff1744] text-white border border-white rounded-full flex items-center justify-center font-lilita text-[10px] font-bold shadow-sm">
              {boosters.spin > 0 ? boosters.spin : '+'}
            </div>
          </button>

          {/* Booster 4: Undo Spoon */}
          <button
            onClick={() => handleUseBooster('undo')}
            className="relative w-12 h-12 rounded-xl bg-gradient-to-b from-[#29b6f6] to-[#0288d1] border-2 border-white shadow-[0_3px_0_#01579b] flex items-center justify-center text-2xl active:translate-y-0.5 transition-all"
            title="Magic Spoon: Undo last move"
          >
            ↩️
            <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#ff1744] text-white border border-white rounded-full flex items-center justify-center font-lilita text-[10px] font-bold shadow-sm">
              {boosters.undo > 0 ? boosters.undo : '+'}
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
