import React from 'react';
import { X, Sparkles, Lock, ArrowDown } from 'lucide-react';
import { CANDY_DEFS } from '../utils/candyConstants';
import { sounds } from '../utils/audio';

interface CandyTiersModalProps {
  highestCandyTier: number;
  onClose: () => void;
}

export const CandyTiersModal: React.FC<CandyTiersModalProps> = ({
  highestCandyTier,
  onClose
}) => {
  const standardLevels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
  const specialLevels = [99, 100];

  const vnNames: Record<number, string> = {
    1: 'Kẹo Vàng (Hạt Đậu)',
    2: 'Kẹo Tím (Hình Nón)',
    3: 'Kẹo Xanh Dương (Bầu Dục)',
    4: 'Kẹo Hồng Vuông (Thạch)',
    5: 'Ngôi Sao Cam',
    6: 'Kẹo Xoáy Xanh (Bạc Hà)',
    7: 'Kẹo Xoáy Cam (Caramel)',
    8: 'Kẹo Đốm Hồng (Dâu Tây)',
    9: 'Kẹo Hoa Lục Bảo',
    10: 'Kẹo Pha Lê Tím',
    11: 'Kẹo Trái Tim Hồng',
    99: 'Kẹo Cầu Vồng (Vạn Năng)',
    100: 'Kẹo Bom Donut (Nổ 3x3)'
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-[360px] max-h-[92%] bg-gradient-to-b from-[#fce4ec] via-[#fff] to-[#f8bbd0] rounded-3xl border-4 border-white shadow-2xl p-4 flex flex-col items-center overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onClose();
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#ff1744] text-white border-2 border-white shadow-md flex items-center justify-center active:scale-90 transition-transform z-20"
        >
          <X className="w-5 h-5 stroke-[3]" />
        </button>

        {/* Modal Header */}
        <div className="relative flex flex-col items-center mt-1 mb-2 text-center">
          <div className="flex items-center gap-1.5">
            <span className="text-2xl animate-bounce">🍬</span>
            <h3 className="font-lilita text-2xl text-[#d81b60] tracking-wide text-candy-stroke">
              CẤP BẬC KẸO
            </h3>
            <span className="text-2xl animate-bounce">🍭</span>
          </div>
          <p className="font-fredoka text-[11px] text-[#ad1457] font-semibold">
            Gộp 3 kẹo cùng loại để tiến hóa lên cấp bậc cao hơn!
          </p>
        </div>

        {/* Scrollable Candy Evolution List */}
        <div className="w-full flex-1 overflow-y-auto pr-1 space-y-2.5 my-1 custom-scrollbar">
          {standardLevels.map((lvl, idx) => {
            const def = CANDY_DEFS[lvl];
            const nextDef = CANDY_DEFS[lvl + 1];
            const isUnlocked = lvl <= Math.max(3, highestCandyTier);

            return (
              <div key={lvl} className="flex flex-col items-center">
                {/* Candy Card */}
                <div
                  className={`w-full rounded-2xl border-2 p-2.5 flex items-center justify-between transition-all ${
                    isUnlocked
                      ? 'bg-white/95 border-pink-300 shadow-sm'
                      : 'bg-slate-100/90 border-slate-300 opacity-70'
                  }`}
                >
                  {/* Left: Candy Icon & Level Badge */}
                  <div className="flex items-center gap-2.5">
                    <div
                      className="relative w-11 h-11 rounded-full flex items-center justify-center text-2xl border-2 border-white shadow-md"
                      style={{
                        backgroundColor: isUnlocked ? `${def.color}dd` : '#9e9e9e',
                        boxShadow: isUnlocked ? `0 0 10px ${def.color}aa` : 'none'
                      }}
                    >
                      {isUnlocked ? (
                        <span>{def.icon}</span>
                      ) : (
                        <Lock className="w-5 h-5 text-white" />
                      )}

                      {/* Level Pill */}
                      <span className="absolute -bottom-1 -right-1 bg-[#d81b60] text-white font-lilita text-[9px] px-1.5 py-0.2 rounded-full border border-white">
                        Cấp {lvl}
                      </span>
                    </div>

                    {/* Middle: Name & Status */}
                    <div className="flex flex-col text-left">
                      <span className="font-lilita text-sm text-slate-800 leading-tight">
                        {vnNames[lvl]}
                      </span>
                      <span className="font-fredoka text-[10px] text-pink-700 font-medium">
                        {def.name}
                      </span>
                      {!isUnlocked && (
                        <span className="font-fredoka text-[9px] text-amber-700 font-bold mt-0.5">
                          🔒 Chưa tạo được
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right: Scores & Stars */}
                  <div className="flex flex-col items-end font-lilita text-right">
                    <span className="text-xs text-[#0288d1]">
                      +{def.scoreValue.toLocaleString()} đ
                    </span>
                    <span className="text-[11px] text-[#f57f17] flex items-center gap-0.5 font-bold">
                      +{def.starBonus} ⭐
                    </span>
                  </div>
                </div>

                {/* Arrow connecting to next level */}
                {nextDef && (
                  <div className="flex items-center justify-center my-0.5 text-pink-400">
                    <ArrowDown className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </div>
            );
          })}

          {/* Section: Special Candies */}
          <div className="pt-2 border-t border-pink-200">
            <div className="font-lilita text-xs text-[#7b1fa2] flex items-center gap-1 mb-2">
              <Sparkles className="w-3.5 h-3.5" /> KẸO ĐẶC BIỆT & BỔ TRỢ
            </div>

            <div className="space-y-2">
              {specialLevels.map((lvl) => {
                const def = CANDY_DEFS[lvl];
                return (
                  <div
                    key={lvl}
                    className="w-full bg-gradient-to-r from-amber-50 via-white to-pink-50 rounded-2xl border-2 border-amber-300 p-2.5 flex items-center justify-between shadow-sm"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#ffd54f] to-[#ff4081] flex items-center justify-center text-2xl border-2 border-white shadow-md">
                        {def.icon}
                      </div>

                      <div className="flex flex-col text-left">
                        <span className="font-lilita text-sm text-amber-950 leading-tight">
                          {vnNames[lvl]}
                        </span>
                        <span className="font-fredoka text-[10px] text-purple-700 font-medium">
                          {lvl === 99
                            ? 'Ghép với 2 kẹo bất kỳ để gộp'
                            : 'Nổ tung bán kính 3x3 ô'}
                        </span>
                      </div>
                    </div>

                    <div className="font-lilita text-xs text-emerald-700 font-bold">
                      VẬT PHẨM
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onClose();
          }}
          className="w-full mt-2 py-2 rounded-full bg-gradient-to-b from-[#ff4081] to-[#c2185b] border-2 border-white shadow-md text-white font-lilita text-sm tracking-wider active:scale-95 transition-transform"
        >
          ĐÓNG
        </button>
      </div>
    </div>
  );
};
