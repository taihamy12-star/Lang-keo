import React, { useState } from 'react';
import { ArrowLeft, X, Lock, Check } from 'lucide-react';
import { Village } from '../types/game';
import { sounds } from '../utils/audio';

interface VillageSelectScreenProps {
  villages: Village[];
  currentVillageId: number;
  stars: number;
  onBack: () => void;
  onSelectVillage: (villageId: number) => void;
  onUnlockVillage: (villageId: number) => void;
  onOpenShop: () => void;
}

export const VillageSelectScreen: React.FC<VillageSelectScreenProps> = ({
  villages,
  currentVillageId,
  stars,
  onBack,
  onSelectVillage,
  onUnlockVillage,
  onOpenShop
}) => {
  const [index, setIndex] = useState(() => {
    const found = villages.findIndex((v) => v.id === currentVillageId);
    return found >= 0 ? found : 0;
  });

  const village = villages[index];

  const handlePrev = () => {
    sounds.playTap();
    setIndex((prev) => (prev > 0 ? prev - 1 : villages.length - 1));
  };

  const handleNext = () => {
    sounds.playTap();
    setIndex((prev) => (prev < villages.length - 1 ? prev + 1 : 0));
  };

  return (
    <div className="relative w-full h-full flex flex-col justify-between items-center bg-[#4a154b] p-3 select-none overflow-hidden">
      {/* Striped Wallpaper Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#6a1b9a] via-[#8e24aa] to-[#4a148c] opacity-90" />
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage:
            'repeating-linear-gradient(90deg, #fff, #fff 20px, transparent 20px, transparent 40px)'
        }}
      />

      {/* Top Header Bar */}
      <div className="relative z-10 w-full flex justify-between items-center px-1 pt-1">
        {/* Blue Back Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onBack();
          }}
          className="w-10 h-10 rounded-full bg-gradient-to-b from-[#40c4ff] to-[#0288d1] border-2 border-white shadow-md flex items-center justify-center text-white active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-6 h-6 stroke-[3]" />
        </button>

        {/* Star Counter Pill */}
        <div className="flex items-center bg-white border-3 border-[#ffcc00] rounded-full pl-2 pr-1 py-0.5 shadow-md">
          <span className="text-xl mr-1">⭐</span>
          <span className="font-lilita text-base tracking-wide text-amber-900 mr-2">
            {stars.toLocaleString()}
          </span>
          <button
            onClick={() => {
              sounds.playTap();
              onOpenShop();
            }}
            className="w-6 h-6 rounded-full bg-gradient-to-b from-[#e91e63] to-[#ad1457] text-white flex items-center justify-center font-bold text-sm shadow-sm active:scale-90"
          >
            +
          </button>
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onBack();
          }}
          className="w-10 h-10 rounded-full bg-gradient-to-b from-[#ff1744] to-[#c2185b] border-2 border-white shadow-md flex items-center justify-center text-white active:scale-95 transition-transform"
        >
          <X className="w-6 h-6 stroke-[3]" />
        </button>
      </div>

      {/* Village Title Banner */}
      <div className="relative z-10 my-1 text-center">
        <h2 className="font-lilita text-3xl tracking-wide text-white drop-shadow-[0_3px_0_#4a148c]">
          {village.isUnlocked ? 'UNLOCKED!' : 'LOCKED!'}
        </h2>
        <p className="font-fredoka text-sm font-semibold text-pink-200">{village.name}</p>
      </div>

      {/* Main Carousel Card */}
      <div className="relative z-10 w-full flex-1 max-h-[460px] flex items-center justify-between px-1">
        {/* Left Golden Arrow */}
        <button
          onClick={handlePrev}
          className="w-10 h-14 bg-gradient-to-r from-[#ffd54f] to-[#ffb300] border-2 border-white rounded-l-md shadow-lg flex items-center justify-center text-amber-900 text-2xl font-black active:scale-90 transition-transform -ml-2"
        >
          ◀
        </button>

        {/* Village Center Card Frame */}
        <div className="relative flex-1 max-w-[280px] mx-auto bg-white rounded-2xl border-4 border-[#81d4fa] shadow-[0_8px_16px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col items-center">
          {/* Frosted pink icing top drape */}
          <div className="absolute top-0 inset-x-0 h-6 bg-pink-300 rounded-b-xl border-b-2 border-white z-20 flex items-center justify-around px-2">
            <span className="w-2 h-0.5 bg-yellow-300 rounded-full" />
            <span className="w-2 h-0.5 bg-cyan-300 rounded-full" />
            <span className="w-2 h-0.5 bg-red-400 rounded-full" />
            <span className="w-2 h-0.5 bg-emerald-300 rounded-full" />
          </div>

          {/* Number Ribbon Banner on Top-Left */}
          <div className="absolute top-1 left-2 z-30 bg-gradient-to-b from-[#e91e63] to-[#c2185b] border border-white text-white font-lilita text-sm px-2 py-0.5 rounded-sm shadow-sm">
            {village.id}
          </div>

          {/* Card Artwork Image */}
          <div className="relative w-full h-44 overflow-hidden bg-slate-900">
            <img
              src={village.image}
              alt={village.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />

            {/* Lock Overlay if Locked */}
            {!village.isUnlocked && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-2">
                <div className="w-14 h-14 rounded-full bg-slate-300 border-3 border-white shadow-inner flex items-center justify-center text-slate-800">
                  <Lock className="w-8 h-8 stroke-[2.5]" />
                </div>
              </div>
            )}
          </div>

          {/* Village Perks & Stats Section */}
          <div className="w-full p-3 bg-gradient-to-b from-amber-50 to-orange-100 flex flex-col items-center gap-1.5 text-center font-lilita">
            <div className="w-full flex justify-between px-2 text-xs text-amber-950 font-bold border-b border-amber-200 pb-1">
              <span>Initial Items:</span>
              <span className="text-[#d81b60] text-sm">{village.initialItems}</span>
            </div>

            <div className="w-full flex justify-between px-2 text-xs text-amber-950 font-bold border-b border-amber-200 pb-1">
              <span>Wild Mana:</span>
              <span className="text-[#0288d1] text-sm">{village.wildMana}</span>
            </div>

            <div className="w-full flex justify-between px-2 text-xs text-amber-950 font-bold">
              <span>Extra Score:</span>
              <span className="text-[#2e7d32] text-sm">+{village.extraScorePercent}%</span>
            </div>
          </div>
        </div>

        {/* Right Golden Arrow */}
        <button
          onClick={handleNext}
          className="w-10 h-14 bg-gradient-to-l from-[#ffd54f] to-[#ffb300] border-2 border-white rounded-r-md shadow-lg flex items-center justify-center text-amber-900 text-2xl font-black active:scale-90 transition-transform -mr-2"
        >
          ▶
        </button>
      </div>

      {/* Bottom Action Button (Unlock or Play) */}
      <div className="relative z-10 w-full max-w-[280px] my-2">
        {village.isUnlocked ? (
          <button
            onClick={() => {
              sounds.playTap();
              onSelectVillage(village.id);
            }}
            className="w-full py-3 rounded-full bg-gradient-to-b from-[#00e676] to-[#00b0ff] border-3 border-white shadow-[0_5px_0_#0091ea] text-white font-lilita text-lg tracking-wider active:translate-y-1 active:shadow-[0_2px_0_#0091ea] transition-all flex items-center justify-center gap-2"
          >
            <Check className="w-6 h-6 stroke-[3]" />
            PLAY VILLAGE
          </button>
        ) : (
          <button
            onClick={() => {
              sounds.playTap();
              onUnlockVillage(village.id);
            }}
            disabled={stars < village.cost}
            className={`w-full py-3 rounded-full border-3 border-white shadow-[0_5px_0_#c2185b] font-lilita text-lg tracking-wider flex items-center justify-center gap-2 transition-all ${
              stars >= village.cost
                ? 'bg-gradient-to-b from-[#ffd54f] to-[#ff9800] text-amber-950 active:translate-y-1'
                : 'bg-slate-400 text-slate-200 cursor-not-allowed opacity-80'
            }`}
          >
            <span className="text-xl">⭐</span>
            <span>{village.cost.toLocaleString()}</span>
          </button>
        )}
      </div>
    </div>
  );
};
