import React from 'react';
import { Volume2, VolumeX, Music, HelpCircle } from 'lucide-react';
import { GameMode, SavedGameState } from '../types/game';
import { sounds } from '../utils/audio';

interface TitleScreenProps {
  stars: number;
  gameMode: GameMode;
  isGiftClaimedToday: boolean;
  savedGame: SavedGameState | null;
  onResume: () => void;
  onNewGame: () => void;
  onOpenVillages: () => void;
  onOpenCandyTiers: () => void;
  onOpenGameModes: () => void;
  onOpenGift: () => void;
  onOpenStats: () => void;
  onOpenHelp: () => void;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  stars,
  gameMode,
  isGiftClaimedToday,
  savedGame,
  onResume,
  onNewGame,
  onOpenVillages,
  onOpenCandyTiers,
  onOpenGameModes,
  onOpenGift,
  onOpenStats,
  onOpenHelp,
  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic
}) => {
  return (
    <div className="relative w-full h-full flex flex-col justify-between items-center overflow-hidden bg-gradient-to-b from-[#ff80ab] via-[#f06292] to-[#c2185b] select-none">
      {/* Background Candy Art */}
      <img
        src="/src/assets/images/title_candy_art_1791124724762.jpg"
        alt="Candy Village Wonderland"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover opacity-90 pointer-events-none"
      />

      {/* Floating Sparkles & Candy Bokeh */}
      <div className="absolute inset-0 bg-radial from-transparent via-transparent to-pink-900/40 pointer-events-none" />

      {/* Top Header Bar: Sound Controls & Help */}
      <div className="relative z-10 w-full px-4 pt-3 flex justify-between items-center">
        {/* Star Counter Pill on Title */}
        <div className="flex items-center bg-white/95 border-3 border-[#ffcc00] rounded-full pl-2 pr-3 py-0.5 shadow-md">
          <span className="text-xl mr-1">⭐</span>
          <span className="font-lilita text-base tracking-wide text-amber-900">
            {stars.toLocaleString()}
          </span>
        </div>

        {/* Audio and Help Pill Group */}
        <div className="flex items-center gap-1.5 bg-black/25 backdrop-blur-xs p-1 rounded-full border border-white/40">
          <button
            onClick={() => {
              sounds.playTap();
              onToggleSound();
            }}
            className="w-8 h-8 rounded-full bg-white/90 text-pink-700 flex items-center justify-center shadow-xs active:scale-90 transition-transform cursor-pointer"
            title="Toggle Sound Effects"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          <button
            onClick={() => {
              sounds.playTap();
              onToggleMusic();
            }}
            className={`w-8 h-8 rounded-full flex items-center justify-center shadow-xs active:scale-90 transition-transform cursor-pointer ${
              musicEnabled ? 'bg-[#ff4081] text-white' : 'bg-white/90 text-slate-400'
            }`}
            title="Toggle Music"
          >
            <Music className="w-4 h-4" />
          </button>

          {/* Music Volume Slider */}
          <div className="flex items-center gap-1 bg-white/95 px-2 py-1 rounded-full shadow-xs">
            <span className="text-[10px]">🔊</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={sounds.musicVolume}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                sounds.setMusicVolume(val);
              }}
              className="w-14 accent-[#ff4081] cursor-pointer"
              title="Điều chỉnh âm lượng nhạc nền"
            />
          </div>

          <button
            onClick={() => {
              sounds.playTap();
              onOpenHelp();
            }}
            className="w-8 h-8 rounded-full bg-white/90 text-pink-700 flex items-center justify-center shadow-xs active:scale-90 transition-transform cursor-pointer"
            title="Help & Rules"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Center Section: Candy Village 3D Bubble Logo & Play Button */}
      <div className="relative z-10 flex flex-col items-center mt-2 w-full max-w-[340px]">
        {/* Candy Frosted Banner */}
        <div className="relative flex flex-col items-center">
          {/* Frosting drips */}
          <div className="absolute -top-3 w-44 h-7 bg-pink-100 rounded-full border-2 border-white shadow-sm flex items-center justify-around px-2 z-20">
            <span className="w-2.5 h-1 bg-cyan-400 rounded-full rotate-12" />
            <span className="w-2.5 h-1 bg-yellow-400 rounded-full -rotate-45" />
            <span className="w-2.5 h-1 bg-purple-500 rounded-full rotate-30" />
            <span className="w-2.5 h-1 bg-red-400 rounded-full rotate-90" />
            <span className="w-2.5 h-1 bg-emerald-400 rounded-full -rotate-12" />
          </div>

          {/* Main Logo Container */}
          <div className="relative bg-gradient-to-b from-[#29b6f6] to-[#0288d1] p-3 pt-4 rounded-3xl border-4 border-white shadow-[0_8px_0_#01579b,0_12px_20px_rgba(0,0,0,0.4)] flex flex-col items-center text-center">
            {/* LÀNG */}
            <span className="font-lilita text-4xl sm:text-5xl tracking-wider text-white drop-shadow-[0_4px_0_#d81b60] leading-none text-candy-stroke">
              LÀNG
            </span>
            {/* KẸO */}
            <span className="font-lilita text-4xl sm:text-5xl tracking-wider text-[#ffeb3b] drop-shadow-[0_4px_0_#f57f17] leading-none mt-1 text-candy-stroke">
              KẸO
            </span>

            {/* Candy Cane & Lollipop Decors */}
            <div className="absolute -left-3 -bottom-2 text-2xl animate-bounce">🍬</div>
            <div className="absolute -right-3 -top-2 text-2xl animate-pulse">🍭</div>
          </div>
        </div>

        {/* Play / Resume Buttons */}
        {savedGame ? (
          <div className="flex flex-col items-center gap-2.5 mt-5 w-full px-4">
            {/* Resume Button */}
            <button
              onClick={() => {
                sounds.playTap();
                onResume();
              }}
              className="group relative w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#00e676] via-[#00c853] to-[#2e7d32] border-3 border-white shadow-[0_6px_0_#1b5e20,0_10px_20px_rgba(0,0,0,0.35)] flex items-center justify-between transform active:translate-y-1 active:shadow-[0_2px_0_#1b5e20] transition-all hover:scale-[1.02] cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/30 border-2 border-white flex items-center justify-center text-white text-xl shadow-inner group-hover:scale-110 transition-transform">
                  ▶
                </div>
                <div className="flex flex-col items-start text-left">
                  <span className="font-lilita text-lg tracking-wider text-white drop-shadow-[0_2px_0_#1b5e20] leading-tight">
                    TIẾP TỤC VÁN CHƠI
                  </span>
                  <span className="font-fredoka text-[11px] text-yellow-200 font-semibold">
                    Điểm: {savedGame.score.toLocaleString()} • {savedGame.totalMerges} lượt gộp
                  </span>
                </div>
              </div>
              <span className="text-2xl animate-bounce">🍬</span>
            </button>

            {/* New Game Button */}
            <button
              onClick={() => {
                sounds.playTap();
                onNewGame();
              }}
              className="py-1 px-3.5 rounded-full bg-white/90 hover:bg-white border-2 border-pink-300 text-[#ad1457] font-lilita text-[11px] tracking-wider uppercase shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1"
            >
              <span>🔄</span>
              <span>Chơi ván mới (Xóa ván cũ)</span>
            </button>
          </div>
        ) : (
          /* Big Pink Glossy Play Button */
          <button
            onClick={() => {
              sounds.playTap();
              onNewGame();
            }}
            className="group relative mt-8 w-28 h-28 rounded-3xl bg-gradient-to-b from-[#ff4081] via-[#e91e63] to-[#ad1457] border-4 border-white shadow-[0_8px_0_#880e4f,0_12px_25px_rgba(0,0,0,0.4)] flex items-center justify-center transform active:translate-y-1.5 active:shadow-[0_2px_0_#880e4f] transition-all hover:scale-105 cursor-pointer"
          >
            {/* Inner Gloss */}
            <div className="absolute inset-1.5 rounded-2xl bg-gradient-to-b from-white/40 via-transparent to-black/10 pointer-events-none" />

            {/* Golden Play Triangle */}
            <div className="w-0 h-0 border-y-[20px] border-y-transparent border-l-[32px] border-l-[#ffeb3b] ml-2 drop-shadow-[0_3px_0_#f57f17] group-hover:scale-110 transition-transform" />
          </button>
        )}

        {/* Village Selection, Game Mode & Candy Tiers Shortcuts */}
        <div className="flex flex-col items-center gap-2 mt-3">
          {/* Active Game Mode Selector Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onOpenGameModes();
            }}
            className="px-3.5 py-1.5 rounded-full border-2 border-white shadow-md font-lilita text-xs tracking-wider uppercase flex items-center gap-1.5 active:scale-95 transition-all text-white cursor-pointer hover:brightness-110"
            style={{ backgroundColor: gameMode.color }}
            title="Đổi Chế Độ Chơi (5 Chế Độ)"
          >
            <span>{gameMode.icon}</span>
            <span>Chế Độ: {gameMode.nameVn}</span>
            <span className="text-[10px] bg-black/20 rounded-full px-1.5 py-0.2">
              {gameMode.spawnPerTurn === 1 ? '1 Kẹo/Lượt' : `+${gameMode.spawnPerTurn} Kẹo/Lượt`}
            </span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sounds.playTap();
                onOpenVillages();
              }}
              className="px-3 py-1.5 rounded-full bg-white/95 border-2 border-[#ff80ab] text-[#ad1457] font-lilita text-xs tracking-wider uppercase shadow-md hover:bg-white active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>🏰</span>
              <span>Bản Đồ</span>
            </button>

            <button
              onClick={() => {
                sounds.playTap();
                onOpenCandyTiers();
              }}
              className="px-3 py-1.5 rounded-full bg-gradient-to-r from-[#ab47bc] to-[#ec407a] border-2 border-white text-white font-lilita text-xs tracking-wider uppercase shadow-md hover:brightness-110 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>🍬</span>
              <span>Cấp Bậc Kẹo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Section: Gift, Trophy, Sound controls & Candy Pile */}
      <div className="relative z-10 w-full flex flex-col items-center">
        {/* Interactive Wand & Cane Row */}
        <div className="w-full px-6 flex justify-between items-end pb-3">
          {/* Left: Gift Lollipop Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onOpenGift();
            }}
            className="relative flex flex-col items-center group active:scale-95 transition-transform cursor-pointer"
            title={isGiftClaimedToday ? 'Đã nhận quà hôm nay' : 'Nhận quà hàng ngày miễn phí!'}
          >
            {/* Free or Claimed Status Badge */}
            {!isGiftClaimedToday ? (
              <span className="absolute -top-2 -right-2 z-20 bg-gradient-to-r from-amber-400 to-yellow-300 text-amber-950 border-2 border-white rounded-full font-lilita text-[10px] px-1.5 py-0.5 shadow-md animate-bounce">
                FREE!
              </span>
            ) : (
              <span className="absolute -top-1 -right-1 z-20 bg-emerald-600 text-white border-2 border-white rounded-full font-lilita text-[9px] w-5 h-5 flex items-center justify-center shadow-sm">
                ✓
              </span>
            )}

            {/* Lollipop Head */}
            <div
              className={`w-14 h-14 rounded-full border-3 border-white shadow-[0_4px_0_#b71c1c] flex items-center justify-center text-white font-lilita text-base tracking-wide text-candy-stroke group-hover:rotate-12 transition-transform ${
                isGiftClaimedToday
                  ? 'bg-gradient-to-br from-[#b0bec5] via-[#90a4ae] to-[#607d8b]'
                  : 'bg-gradient-to-br from-[#ff1744] via-[#ff4081] to-[#00e676]'
              }`}
            >
              Gift
            </div>
            {/* Striped Stick */}
            <div className="w-2.5 h-7 candy-stripe-pink border border-white -mt-0.5 rounded-b-sm shadow-sm" />
          </button>

          {/* Middle: Star Trophy Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onOpenStats();
            }}
            className="flex flex-col items-center group active:scale-95 transition-transform"
          >
            <div className="w-14 h-14 rounded-full bg-gradient-to-b from-[#ffee58] to-[#fbc02d] border-3 border-white shadow-[0_4px_0_#f57f17] flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
              🏆
            </div>
            {/* Green Stick */}
            <div className="w-2.5 h-6 bg-gradient-to-b from-[#66bb6a] to-[#2e7d32] border border-white -mt-0.5 rounded-b-sm shadow-sm" />
          </button>

          {/* Right: Rainbow Magic Wand */}
          <button
            onClick={() => {
              sounds.playRainbow();
              onOpenCandyTiers();
            }}
            className="flex flex-col items-center group active:scale-95 transition-transform"
          >
            {/* Star Top */}
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#00e5ff] via-[#d500f9] to-[#ffea00] border-3 border-white shadow-[0_4px_0_#aa00ff] flex items-center justify-center text-2xl group-hover:rotate-45 transition-transform">
              ⭐
            </div>
            {/* Wand Stick */}
            <div className="w-2.5 h-7 bg-gradient-to-b from-[#d500f9] to-[#651fff] border border-white -mt-0.5 rounded-b-sm shadow-sm" />
          </button>
        </div>

        {/* Bottom Pink Chocolate Ground Border */}
        <div className="w-full h-4 bg-gradient-to-r from-[#ad1457] via-[#ec407a] to-[#ad1457] border-t-2 border-white flex items-center justify-around px-4">
          <div className="w-3 h-3 rounded-full bg-[#ffeb3b] border border-white shadow-xs" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#00e5ff] border border-white shadow-xs" />
          <div className="w-3 h-3 rounded-full bg-[#76ff03] border border-white shadow-xs" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#ff4081] border border-white shadow-xs" />
          <div className="w-3 h-3 rounded-full bg-[#ffeb3b] border border-white shadow-xs" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#00e5ff] border border-white shadow-xs" />
        </div>
      </div>
    </div>
  );
};
