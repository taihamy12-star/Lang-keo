import React from 'react';
import { X } from 'lucide-react';
import { sounds } from '../utils/audio';

interface BoosterBuyModalProps {
  boosterType: 'rainbow' | 'bomb' | 'spin' | 'undo';
  stars: number;
  onClose: () => void;
  onBuy: (type: 'rainbow' | 'bomb' | 'spin' | 'undo', cost: number) => void;
}

export const BoosterBuyModal: React.FC<BoosterBuyModalProps> = ({
  boosterType,
  stars,
  onClose,
  onBuy
}) => {
  const boosterInfo = {
    rainbow: {
      name: 'Rainbow Candy',
      icon: '🍭',
      cost: 1500,
      desc: 'Acts as any candy to merge immediately'
    },
    bomb: {
      name: 'Candy Bomb',
      icon: '🍩',
      cost: 1000,
      desc: 'Explodes a 3x3 grid of candies'
    },
    spin: {
      name: 'Magic Spinner',
      icon: '🪀',
      cost: 800,
      desc: 'Shuffles all low-tier candies'
    },
    undo: {
      name: 'Magic Spoon',
      icon: '↩️',
      cost: 500,
      desc: 'Undo your last move'
    }
  }[boosterType];

  const canAfford = stars >= boosterInfo.cost;

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      {/* Speech-bubble styled dialog from Screenshot 7 */}
      <div className="relative w-full max-w-[280px] bg-gradient-to-b from-[#fffde7] to-[#fff59d] rounded-2xl border-4 border-[#ffeb3b] shadow-[0_8px_20px_rgba(0,0,0,0.5)] p-4 flex flex-col items-center">
        {/* Top Header Row with Star Cost and X */}
        <div className="w-full flex justify-between items-center mb-1">
          <div className="flex items-center gap-1 bg-white/90 border-2 border-[#ffca28] rounded-full px-2.5 py-0.5 shadow-sm">
            <span className="text-base">⭐</span>
            <span className="font-lilita text-sm text-amber-950 font-bold">
              {boosterInfo.cost}
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-gradient-to-b from-[#ff1744] to-[#c2185b] border-2 border-white shadow-sm flex items-center justify-center text-white"
          >
            <X className="w-4 h-4 stroke-[3]" />
          </button>
        </div>

        {/* Booster Icon & Name */}
        <div className="w-16 h-16 rounded-full bg-white border-2 border-amber-300 shadow-md flex items-center justify-center text-3xl my-2">
          {boosterInfo.icon}
        </div>

        <h4 className="font-lilita text-lg text-[#ad1457] tracking-wide mb-1">
          {boosterInfo.name}
        </h4>
        <p className="font-fredoka text-xs text-amber-900 text-center mb-3">
          {boosterInfo.desc}
        </p>

        {/* Buy Button */}
        <button
          onClick={() => {
            sounds.playStarCoin();
            onBuy(boosterType, boosterInfo.cost);
          }}
          disabled={!canAfford}
          className={`w-full py-2 rounded-xl font-lilita text-base tracking-wider border-2 border-white shadow-md active:scale-95 transition-all ${
            canAfford
              ? 'bg-gradient-to-b from-[#29b6f6] to-[#0288d1] text-white shadow-[0_3px_0_#01579b]'
              : 'bg-slate-400 text-slate-200 cursor-not-allowed'
          }`}
        >
          {canAfford ? 'BUY' : 'NEED MORE ⭐'}
        </button>
      </div>
    </div>
  );
};
