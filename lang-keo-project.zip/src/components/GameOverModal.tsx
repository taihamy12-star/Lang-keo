import React, { useEffect } from 'react';
import { Home, Trophy, RotateCcw } from 'lucide-react';
import { CANDY_DEFS, BREAKDOWN_LEVELS } from '../utils/candyConstants';
import { sounds } from '../utils/audio';
import { triggerHighScoreCelebration } from '../utils/confettiEffects';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHigh: boolean;
  candyStats: Record<number, number>;
  totalBonusStars: number;
  onHome: () => void;
  onStats: () => void;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHigh,
  candyStats,
  totalBonusStars,
  onHome,
  onStats,
  onRestart
}) => {
  useEffect(() => {
    if (isNewHigh) {
      triggerHighScoreCelebration();
    }
  }, [isNewHigh]);
  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-center items-center p-3 select-none animate-in fade-in duration-300">
      {/* Modal Container */}
      <div className="relative w-full max-w-[360px] bg-gradient-to-b from-[#ffebee] via-[#fff] to-[#fce4ec] rounded-3xl border-4 border-white shadow-[0_12px_32px_rgba(0,0,0,0.6)] p-3.5 flex flex-col items-center">
        {/* Top Header: GAME OVER */}
        <div className="relative flex flex-col items-center mt-1">
          {/* Header 3D Candy Text */}
          <div className="relative flex items-center justify-center">
            <h1 className="font-lilita text-4xl sm:text-5xl tracking-wider text-[#7cb342] text-candy-stroke leading-none">
              GAME
            </h1>
            <div className="text-3xl ml-1 -mt-2">🍬</div>
          </div>

          <div className="relative flex items-center justify-center -mt-1">
            <h2 className="font-lilita text-4xl sm:text-5xl tracking-wider text-[#ffb300] text-candy-stroke leading-none">
              OVER
            </h2>

            {/* "New!!" Starburst Badge */}
            {isNewHigh && (
              <div className="absolute -right-10 -bottom-2 bg-gradient-to-tr from-[#0288d1] to-[#40c4ff] text-white border-2 border-white rounded-full px-2 py-0.5 font-lilita text-xs tracking-wider shadow-md rotate-12 animate-pulse">
                New!!
              </div>
            )}
          </div>
        </div>

        {/* Scores Display */}
        <div className="w-full text-center mt-3 mb-2 flex flex-col gap-0.5">
          <div className="font-lilita text-xl sm:text-2xl text-[#d81b60] tracking-wide">
            SCORE: <span className="font-bold">{score.toLocaleString()}</span>
          </div>
          <div className="font-lilita text-sm text-[#ec407a] tracking-wide">
            HIGH SCORE: <span>{highScore.toLocaleString()}</span>
          </div>
        </div>

        {/* 2x3 Candy Breakdown Grid */}
        <div className="w-full grid grid-cols-2 gap-2 my-2">
          {BREAKDOWN_LEVELS.map((lvl) => {
            const def = CANDY_DEFS[lvl];
            const count = candyStats[lvl] || 0;
            const points = count * def.starBonus;

            return (
              <div
                key={lvl}
                className="candy-scallop p-1.5 flex items-center justify-between"
              >
                {/* Candy icon */}
                <div className="w-8 h-8 rounded-full bg-white/80 border border-white flex items-center justify-center text-lg shadow-sm">
                  {def.icon}
                </div>

                {/* Count and Star Reward */}
                <div className="flex flex-col items-end font-lilita">
                  <span className="text-xs text-sky-900 font-bold">X{count}=</span>
                  <span className="text-xs text-[#0288d1] flex items-center gap-0.5">
                    {points} ⭐
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Total Star Reward Banner */}
        <div className="w-full bg-gradient-to-r from-amber-100 via-yellow-200 to-amber-100 border-2 border-white rounded-2xl py-2 px-3 my-2 flex items-center justify-center gap-2 shadow-inner">
          <span className="text-3xl animate-bounce">⭐</span>
          <span className="font-lilita text-3xl text-amber-900 tracking-wide">
            +{totalBonusStars.toLocaleString()}
          </span>
        </div>

        {/* Three Action Buttons */}
        <div className="w-full flex justify-around items-center mt-3 pt-2 border-t border-pink-200">
          {/* Blue House Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onHome();
            }}
            className="w-14 h-14 rounded-full bg-gradient-to-b from-[#29b6f6] to-[#0288d1] border-3 border-white shadow-[0_4px_0_#01579b] flex items-center justify-center text-white active:translate-y-1 active:shadow-[0_1px_0_#01579b] transition-transform"
            title="Villages"
          >
            <Home className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* Green Trophy Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onStats();
            }}
            className="w-14 h-14 rounded-full bg-gradient-to-b from-[#66bb6a] to-[#2e7d32] border-3 border-white shadow-[0_4px_0_#1b5e20] flex items-center justify-center text-white active:translate-y-1 active:shadow-[0_1px_0_#1b5e20] transition-transform"
            title="Achievements"
          >
            <Trophy className="w-7 h-7 stroke-[2.5]" />
          </button>

          {/* Magenta Restart Button */}
          <button
            onClick={() => {
              sounds.playTap();
              onRestart();
            }}
            className="w-14 h-14 rounded-full bg-gradient-to-b from-[#ff4081] to-[#c2185b] border-3 border-white shadow-[0_4px_0_#880e4f] flex items-center justify-center text-white active:translate-y-1 active:shadow-[0_1px_0_#880e4f] transition-transform"
            title="Play Again"
          >
            <RotateCcw className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
