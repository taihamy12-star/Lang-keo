import React from 'react';
import { X, Flame, Zap, Clock, ShieldCheck, Star } from 'lucide-react';
import { GameMode, GameModeId } from '../types/game';
import { GAME_MODE_LIST } from '../utils/gameModes';
import { sounds } from '../utils/audio';

interface GameModeSelectModalProps {
  currentModeId: GameModeId;
  onSelectMode: (modeId: GameModeId) => void;
  onClose: () => void;
}

export const GameModeSelectModal: React.FC<GameModeSelectModalProps> = ({
  currentModeId,
  onSelectMode,
  onClose
}) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-[360px] max-h-[92%] bg-gradient-to-b from-[#fff3e0] via-[#fff] to-[#ffe0b2] rounded-3xl border-4 border-white shadow-2xl p-4 flex flex-col items-center overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onClose();
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#ff1744] text-white border-2 border-white shadow-md flex items-center justify-center active:scale-90 transition-transform z-20"
        >
          <X className="w-5 h-5 stroke-[3]" />
        </button>

        {/* Modal Header */}
        <div className="relative flex flex-col items-center mt-1 mb-2 text-center">
          <div className="flex items-center gap-1.5">
            <span className="text-2xl animate-bounce">🎮</span>
            <h3 className="font-lilita text-2xl text-[#d81b60] tracking-wide text-candy-stroke">
              CHẾ ĐỘ CHƠI
            </h3>
            <span className="text-2xl animate-bounce">⚡</span>
          </div>
          <p className="font-fredoka text-[11px] text-[#ad1457] font-semibold">
            Chọn độ khó & số lượng kẹo rơi sau mỗi lượt đi!
          </p>
        </div>

        {/* 5 Modes List */}
        <div className="w-full flex-1 overflow-y-auto pr-1 space-y-2.5 my-1 custom-scrollbar">
          {GAME_MODE_LIST.map((mode: GameMode) => {
            const isSelected = mode.id === currentModeId;

            return (
              <button
                key={mode.id}
                onClick={() => {
                  sounds.playTap();
                  onSelectMode(mode.id);
                  onClose();
                }}
                className={`w-full rounded-2xl border-2 p-2.5 flex flex-col gap-1.5 text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-100/90 border-[#ff9800] shadow-md scale-[1.02]'
                    : 'bg-white/90 border-amber-200 hover:border-amber-400 active:scale-98 shadow-xs'
                }`}
              >
                {/* Header Row: Icon, Name & Multiplier */}
                <div className="w-full flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-xl border-2 border-white shadow-sm"
                      style={{ backgroundColor: `${mode.color}dd` }}
                    >
                      {mode.icon}
                    </div>

                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <span className="font-lilita text-base text-slate-800 leading-none">
                          {mode.nameVn}
                        </span>
                        {isSelected && (
                          <span className="bg-[#4caf50] text-white font-lilita text-[9px] px-1.5 py-0.5 rounded-full border border-white">
                            Đang Chọn
                          </span>
                        )}
                      </div>
                      <span className="font-fredoka text-[10px] text-slate-500 font-medium">
                        {mode.name}
                      </span>
                    </div>
                  </div>

                  {/* Multiplier Badge */}
                  <div className="flex flex-col items-end font-lilita">
                    <span className="text-xs text-[#d81b60] font-bold">
                      x{mode.scoreMultiplier.toFixed(1)} Điểm
                    </span>
                    <span className="text-[10px] text-[#f57f17] flex items-center gap-0.5">
                      {mode.spawnPerTurn === 1 ? '🍬 1 kẹo/lượt' : `🍬 x${mode.spawnPerTurn} kẹo/lượt`}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="font-fredoka text-[11px] text-amber-950 font-normal leading-relaxed pl-1 border-l-2 border-amber-300">
                  {mode.description}
                </p>

                {/* Mode Features Pills */}
                <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                  <span className="bg-amber-50 text-amber-900 border border-amber-200 font-lilita text-[10px] px-2 py-0.5 rounded-md">
                    Khởi đầu: {mode.initialCandies} kẹo
                  </span>
                  {mode.hasTimer && (
                    <span className="bg-purple-100 text-purple-900 border border-purple-300 font-lilita text-[10px] px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Clock className="w-3 h-3 text-purple-700" /> Đồng hồ: {mode.timerSeconds}s
                    </span>
                  )}
                  {mode.spawnPerTurn > 1 && (
                    <span className="bg-rose-100 text-rose-900 border border-rose-300 font-lilita text-[10px] px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-600" /> Rơi +{mode.spawnPerTurn} kẹo
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Bottom Button */}
        <button
          onClick={() => {
            sounds.playTap();
            onClose();
          }}
          className="w-full mt-2 py-2 rounded-full bg-gradient-to-b from-[#ff9800] to-[#f57c00] border-2 border-white shadow-md text-white font-lilita text-sm tracking-wider active:scale-95 transition-transform"
        >
          XÁC NHẬN
        </button>
      </div>
    </div>
  );
};
