import React, { useState, useEffect } from 'react';
import { X, Gift, CheckCircle, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface GiftModalProps {
  isClaimedToday: boolean;
  onClose: () => void;
  onClaim: (reward: { type: 'stars' | 'rainbow' | 'bomb'; amount: number }) => void;
}

export const GiftModal: React.FC<GiftModalProps> = ({
  isClaimedToday,
  onClose,
  onClaim
}) => {
  const [opened, setOpened] = useState<number | null>(null);
  const [countdown, setCountdown] = useState<string>('');

  // Live countdown to midnight (next daily reset)
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0);
      const diffSecs = Math.max(0, Math.floor((tomorrow.getTime() - now.getTime()) / 1000));
      const hours = Math.floor(diffSecs / 3600);
      const mins = Math.floor((diffSecs % 3600) / 60);
      const secs = diffSecs % 60;
      setCountdown(
        `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  const boxes = [
    { id: 1, type: 'stars' as const, amount: 1500, label: '1,500 ⭐', desc: '1,500 Ngôi sao' },
    { id: 2, type: 'rainbow' as const, amount: 2, label: '2x 🍭 Wild', desc: '2 Kẹo Cầu Vồng' },
    { id: 3, type: 'bomb' as const, amount: 2, label: '2x 🍩 Bomb', desc: '2 Kẹo Bom Donut' }
  ];

  const handlePick = (idx: number) => {
    if (isClaimedToday || opened !== null) return;
    setOpened(idx);
    sounds.playComboChime();
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 }
    });
    const reward = boxes[idx];
    setTimeout(() => {
      onClaim(reward);
    }, 1300);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-[340px] bg-gradient-to-b from-[#fff3e0] via-[#fff] to-[#ffe0b2] rounded-3xl border-4 border-white shadow-2xl p-5 flex flex-col items-center text-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute -top-3 -right-3 w-9 h-9 rounded-full bg-[#ff1744] text-white border-2 border-white shadow-md flex items-center justify-center active:scale-90 transition-transform"
        >
          <X className="w-5 h-5 stroke-[3]" />
        </button>

        {/* Modal Icon Badge */}
        <div
          className={`w-14 h-14 rounded-full border-3 border-white shadow-md flex items-center justify-center text-white mb-2 ${
            isClaimedToday
              ? 'bg-gradient-to-br from-[#4caf50] to-[#2e7d32]'
              : 'bg-gradient-to-br from-[#ff4081] to-[#f50057]'
          }`}
        >
          {isClaimedToday ? (
            <CheckCircle className="w-8 h-8" />
          ) : (
            <Gift className="w-7 h-7 animate-bounce" />
          )}
        </div>

        <h3 className="font-lilita text-2xl text-[#d81b60] tracking-wide">
          {isClaimedToday ? 'ĐÃ NHẬN THƯỞNG' : 'QUÀ TẶNG HÀNG NGÀY'}
        </h3>

        {/* Subtitle / Explanation */}
        {isClaimedToday ? (
          <div className="w-full my-2 bg-emerald-50 border-2 border-emerald-300 rounded-2xl p-3 flex flex-col items-center gap-1.5 shadow-xs">
            <p className="font-fredoka text-xs text-emerald-900 font-semibold">
              Hôm nay bạn đã nhận quà rồi!
            </p>
            <p className="font-fredoka text-[11px] text-emerald-700">
              Mỗi ngày bạn chỉ có thể mở 1 hộp quà miễn phí.
            </p>

            {/* Countdown to Next Day Reset */}
            <div className="mt-1 flex items-center gap-1.5 bg-white border border-emerald-300 rounded-full px-3 py-1 font-lilita text-xs text-emerald-800 shadow-2xs">
              <Clock className="w-3.5 h-3.5 text-emerald-600 animate-spin" style={{ animationDuration: '4s' }} />
              <span>Quà mới sau: <strong className="text-emerald-700 tracking-wider font-mono">{countdown}</strong></span>
            </div>
          </div>
        ) : (
          <p className="font-fredoka text-xs text-amber-900 mb-3 font-medium">
            Chọn 1 hộp quà kẹo bất ngờ để nhận Sao hoặc Kẹo Bổ Trợ miễn phí!
            <span className="block text-[11px] text-pink-700 font-bold mt-0.5">
              (Chỉ 1 lần mỗi ngày)
            </span>
          </p>
        )}

        {/* 3 Gift Boxes */}
        <div className="w-full grid grid-cols-3 gap-2.5 my-2">
          {boxes.map((box, idx) => {
            const isChosen = opened === idx;
            return (
              <button
                key={box.id}
                onClick={() => handlePick(idx)}
                disabled={isClaimedToday || opened !== null}
                className={`relative h-28 rounded-2xl border-3 transition-all flex flex-col items-center justify-center p-2 cursor-pointer ${
                  isChosen
                    ? 'bg-amber-300 border-amber-500 scale-105 shadow-lg'
                    : isClaimedToday
                    ? 'opacity-60 border-slate-300 bg-slate-100 cursor-not-allowed'
                    : opened !== null
                    ? 'opacity-40 border-slate-300 bg-slate-100'
                    : 'bg-gradient-to-b from-[#ff80ab] to-[#f06292] border-white shadow-md hover:scale-105 active:scale-95'
                }`}
              >
                {isChosen ? (
                  <div className="flex flex-col items-center animate-bounce">
                    <span className="text-3xl">🎉</span>
                    <span className="font-lilita text-xs text-amber-950 mt-1 font-bold">
                      {box.label}
                    </span>
                  </div>
                ) : isClaimedToday ? (
                  <div className="flex flex-col items-center text-slate-400">
                    <span className="text-3xl">📦</span>
                    <span className="font-lilita text-[10px] text-slate-500 mt-1 font-bold">
                      Đã Nhận
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <span className="text-4xl drop-shadow-sm animate-pulse">🎁</span>
                    <span className="font-lilita text-xs text-white mt-1">
                      Mở Quà
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Button */}
        {isClaimedToday ? (
          <button
            onClick={onClose}
            className="w-full mt-2 py-2 rounded-full bg-gradient-to-b from-[#4caf50] to-[#388e3c] border-2 border-white shadow-md text-white font-lilita text-sm tracking-wider active:scale-95 transition-transform"
          >
            HẸN GẶP LẠI NGÀY MAI!
          </button>
        ) : (
          <p className="font-fredoka text-[10px] text-slate-500 mt-1">
            Chạm vào bất kỳ hộp quà nào ở trên để mở
          </p>
        )}
      </div>
    </div>
  );
};
