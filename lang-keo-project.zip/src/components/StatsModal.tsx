import React from 'react';
import { X, Trophy, Award, Star } from 'lucide-react';
import { CANDY_DEFS, BREAKDOWN_LEVELS } from '../utils/candyConstants';

interface StatsModalProps {
  highScore: number;
  totalMerges: number;
  unlockedVillagesCount: number;
  totalVillagesCount: number;
  highestCandyTier: number;
  stars: number;
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  highScore,
  totalMerges,
  unlockedVillagesCount,
  totalVillagesCount,
  highestCandyTier,
  stars,
  onClose
}) => {
  const highestCandy = CANDY_DEFS[highestCandyTier] || CANDY_DEFS[1];

  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-[340px] bg-gradient-to-b from-[#fffde7] via-[#fff] to-[#fff9c4] rounded-3xl border-4 border-white shadow-2xl p-4 flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#ff1744] text-white border-2 border-white shadow-md flex items-center justify-center"
        >
          <X className="w-5 h-5 stroke-[3]" />
        </button>

        <div className="w-12 h-12 rounded-full bg-gradient-to-b from-[#fbc02d] to-[#f57f17] border-2 border-white shadow-md flex items-center justify-center text-white mb-1">
          <Trophy className="w-6 h-6" />
        </div>

        <h3 className="font-lilita text-2xl text-amber-900 tracking-wide mb-1">RECORDS & TROPHIES</h3>

        {/* Stats Grid */}
        <div className="w-full space-y-2 my-2 font-lilita">
          <div className="bg-white rounded-xl p-2.5 border border-amber-200 shadow-sm flex items-center justify-between">
            <span className="text-xs text-amber-950 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-pink-600" /> High Score
            </span>
            <span className="text-base text-[#d81b60]">{highScore.toLocaleString()}</span>
          </div>

          <div className="bg-white rounded-xl p-2.5 border border-amber-200 shadow-sm flex items-center justify-between">
            <span className="text-xs text-amber-950 flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-500" /> Star Vault
            </span>
            <span className="text-base text-amber-700">{stars.toLocaleString()} ⭐</span>
          </div>

          <div className="bg-white rounded-xl p-2.5 border border-amber-200 shadow-sm flex items-center justify-between">
            <span className="text-xs text-amber-950">Total Candy Merges</span>
            <span className="text-base text-[#0288d1]">{totalMerges.toLocaleString()}</span>
          </div>

          <div className="bg-white rounded-xl p-2.5 border border-amber-200 shadow-sm flex items-center justify-between">
            <span className="text-xs text-amber-950">Highest Candy Created</span>
            <span className="text-sm text-purple-700 flex items-center gap-1">
              {highestCandy.icon} {highestCandy.name}
            </span>
          </div>

          <div className="bg-white rounded-xl p-2.5 border border-amber-200 shadow-sm flex items-center justify-between">
            <span className="text-xs text-amber-950">Villages Unlocked</span>
            <span className="text-base text-emerald-700">
              {unlockedVillagesCount} / {totalVillagesCount}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-3 px-6 py-2 rounded-full bg-gradient-to-b from-[#fbc02d] to-[#f57f17] border-2 border-white text-white font-lilita text-sm tracking-wide shadow-md active:scale-95"
        >
          CLOSE
        </button>
      </div>
    </div>
  );
};
