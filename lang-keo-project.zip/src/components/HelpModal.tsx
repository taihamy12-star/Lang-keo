import React from 'react';
import { X, BookOpen } from 'lucide-react';
import { CANDY_DEFS } from '../utils/candyConstants';

interface HelpModalProps {
  onClose: () => void;
  onOpenCandyTiers?: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ onClose, onOpenCandyTiers }) => {
  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-[360px] max-h-[90%] bg-gradient-to-b from-[#e1f5fe] via-[#fff] to-[#bbdefb] rounded-3xl border-4 border-white shadow-2xl p-4 flex flex-col items-center overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#ff1744] text-white border-2 border-white shadow-md flex items-center justify-center"
        >
          <X className="w-5 h-5 stroke-[3]" />
        </button>

        <div className="w-12 h-12 rounded-full bg-[#29b6f6] border-2 border-white shadow-md flex items-center justify-center text-white mb-1">
          <BookOpen className="w-6 h-6" />
        </div>

        <h3 className="font-lilita text-2xl text-[#0288d1] tracking-wide mb-1">HƯỚNG DẪN CHƠI</h3>
        <p className="font-fredoka text-xs text-slate-600 mb-3 text-center font-medium">
          Làng Kẹo - Trò chơi ghép kẹo kinh điển!
        </p>

        {/* Section 1: Merge Rules */}
        <div className="w-full bg-white/90 rounded-2xl p-3 border border-sky-200 mb-3 shadow-sm text-left font-fredoka text-xs text-slate-800 space-y-2">
          <div className="font-lilita text-sm text-[#0277bd] flex items-center gap-1.5">
            <span>✨</span> 1. Move & Merge 3+ Candies
          </div>
          <p>
            Tap a candy on the board to select it, then tap an empty square to move it there.
            When <strong>3 or more</strong> matching candies connect, they combine into a higher-tier candy!
          </p>

          <div className="bg-sky-50 rounded-xl p-2 border border-sky-100 flex items-center justify-center gap-2 font-lilita text-sm">
            <span>3 🟡</span>
            <span>➡️</span>
            <span>1 🟣</span>
            <span>➡️</span>
            <span>1 🔵</span>
          </div>

          {onOpenCandyTiers && (
            <button
              onClick={() => {
                onClose();
                onOpenCandyTiers();
              }}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white font-lilita text-xs flex items-center justify-center gap-1.5 shadow-sm hover:brightness-110 active:scale-95 transition-all"
            >
              <span>🍬</span>
              <span>XEM TẤT CẢ CẤP BẬC KẸO (1 - 11)</span>
              <span>📖</span>
            </button>
          )}

          <p className="text-[11px] text-slate-500">
            Tip: If a move does not produce a match, a new candy spawns on the board!
          </p>
        </div>

        {/* Section 2: Queue Saucer Placement */}
        <div className="w-full bg-white/90 rounded-2xl p-3 border border-sky-200 mb-3 shadow-sm text-left font-fredoka text-xs text-slate-800 space-y-1.5">
          <div className="font-lilita text-sm text-[#d81b60] flex items-center gap-1.5">
            <span>🍽️</span> 2. Queue Platter Drops
          </div>
          <p>
            Tap the large candy saucer at the top to take the current queue candy, then tap any empty square to place it down directly!
          </p>
        </div>

        {/* Section 3: Boosters */}
        <div className="w-full bg-white/90 rounded-2xl p-3 border border-sky-200 shadow-sm text-left font-fredoka text-xs text-slate-800 space-y-2">
          <div className="font-lilita text-sm text-[#7b1fa2] flex items-center gap-1.5">
            <span>🚀</span> 3. Magical Boosters
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="flex items-center gap-1.5">
              <span className="text-xl">🍭</span>
              <span><strong>Rainbow:</strong> Merges with any candies!</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl">🍩</span>
              <span><strong>Bomb:</strong> Blasts 3x3 tiles!</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl">🪀</span>
              <span><strong>Spin:</strong> Shuffles low candies!</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl">↩️</span>
              <span><strong>Undo:</strong> Reverts last move!</span>
            </div>
          </div>
        </div>

        {/* Section 4: Offline Play */}
        <div className="w-full bg-white/90 rounded-2xl p-3 border border-sky-200 mt-3 shadow-sm text-left font-fredoka text-xs text-slate-800 space-y-1.5">
          <div className="font-lilita text-sm text-[#00897b] flex items-center gap-1.5">
            <span>💾</span> 4. Chơi Offline (Không cần mạng)
          </div>
          <p className="text-[11px] text-slate-600">
            Làng Kẹo chạy hoàn toàn trên máy bạn, không cần internet. Tiến trình chơi được tự động lưu vào bộ nhớ thiết bị.
          </p>
        </div>

        <button
          onClick={onClose}
          className="mt-4 px-6 py-2 rounded-full bg-gradient-to-b from-[#29b6f6] to-[#0288d1] border-2 border-white text-white font-lilita text-sm tracking-wide shadow-md active:scale-95 cursor-pointer"
        >
          ĐÃ HIỂU!
        </button>
      </div>
    </div>
  );
};
