#!/usr/bin/env bash
# Chạy sau khi "npx cap add android": đặt icon game và khóa màn hình dọc.
set -e
RES=android/app/src/main/res
SRC=public/pwa-512x512.png

# Icon launcher: xóa icon thích ứng mặc định, dùng icon của game
rm -rf "$RES"/mipmap-anydpi-v26
for pair in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
  d="${pair%%:*}"; s="${pair##*:}"
  for name in ic_launcher ic_launcher_round ic_launcher_foreground; do
    convert "$SRC" -resize ${s}x${s} "$RES/mipmap-$d/$name.png"
  done
done

# Khóa chơi dọc (portrait)
sed -i 's/android:launchMode="singleTask"/android:launchMode="singleTask" android:screenOrientation="portrait"/' \
  android/app/src/main/AndroidManifest.xml
grep -q screenOrientation android/app/src/main/AndroidManifest.xml
echo "Android setup OK"
